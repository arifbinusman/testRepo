package com.qvantage.recf.api.common.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ContactSaveViewModel {
    private Long userId;
    private String contactDetailType;
    private String contactDetail;
    private Short isPreferredMethod;
}
