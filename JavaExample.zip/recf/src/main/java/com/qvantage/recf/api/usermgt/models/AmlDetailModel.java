package com.qvantage.recf.api.usermgt.models;

import com.qvantage.recf.api.common.BaseModel;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "amldetails")
@ToString(callSuper = true)
public class AmlDetailModel extends BaseModel {

    @Column(name = "userid")
    private Long userId;

    @Column(name = "amlsearchtype")
    private String amlSearchType;

    @Column(name = "amlsearchresult")
    private String amlSearchResult;

    @Column(name = "amlsearchcomments")
    private String amlSearchComments;

    @Column(name = "amlstatus")
    private Short amlStatus;
}
