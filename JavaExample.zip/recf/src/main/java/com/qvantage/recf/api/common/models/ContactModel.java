package com.qvantage.recf.api.common.models;

import com.qvantage.recf.api.common.BaseModel;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "contacts")
@ToString(callSuper = true)
public class ContactModel extends BaseModel {

    @Column(name = "userid")
    private Long userId;

    @Column(name = "contactdetailtype")
    private String contactDetailType;

    @Column(name = "contactdetail")
    private String contactDetail;

    @Column(name = "ispreferredmethod")
    private Short isPreferredMethod;
}
