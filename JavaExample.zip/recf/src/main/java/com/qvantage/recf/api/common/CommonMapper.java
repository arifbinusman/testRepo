package com.qvantage.recf.api.common;

import com.qvantage.recf.api.usermgt.models.UserDetailModel;
import com.qvantage.recf.api.usermgt.viewmodels.InvestorRegistrationStep1ViewModel;
import lombok.SneakyThrows;
import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.stereotype.Service;

@Service
public class CommonMapper {

    @SneakyThrows
    public <T> T transmogrify(T target, Object source) {
        PropertyUtils.copyProperties(target, source);
        return target;
    }
    public UserDetailModel mapUserDetails(InvestorRegistrationStep1ViewModel viewModel)
    {
        var model=new UserDetailModel();
        model.setAccountSource((short) 1);
        model.setAmlFinalStatus(CommonEnums.AMLStatus.INITIATED);
        model.setCitizenShip(viewModel.getCitizenship());
        model.setCountryOfResident(viewModel.getCurrentResidentialCountry());
        model.setDateOfBirth(viewModel.getDateOfBirth());
        model.setKycStatus(CommonEnums.KycStatus.INITIATED);
        model.setOccupation(viewModel.getOccupation());
        model.setUserStatus(CommonEnums.UserStatus.REGISTERED);
        return model;
    }
}
