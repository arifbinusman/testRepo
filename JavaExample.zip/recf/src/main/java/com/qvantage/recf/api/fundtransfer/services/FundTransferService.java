package com.qvantage.recf.api.fundtransfer.services;

import com.qvantage.recf.api.common.CommonEnums;
import com.qvantage.recf.api.common.CommonMapper;
import com.qvantage.recf.api.fundtransfer.models.FundTransferRequestModel;
import com.qvantage.recf.api.fundtransfer.repository.FundTransferDal;
import com.qvantage.recf.api.fundtransfer.repository.FundTransferRepository;
import com.qvantage.recf.api.fundtransfer.viewmodels.FundTransferRequestViewModel;
import com.qvantage.recf.api.transactions.services.UserWalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class FundTransferService {

    @Autowired
    FundTransferRepository repository;

    @Autowired
    CommonMapper commonMapper;

    @Autowired
    FundTransferDal fundTransferDal;

    @Autowired
    UserWalletService userWalletService;

    public void saveFundTransferInRequest(FundTransferRequestViewModel viewModel, Long whoChangedThis) {
        var model = commonMapper.transmogrify(new FundTransferRequestModel(), viewModel);
        model.setDirection(CommonEnums.FundTransferDirection.IN);
        model.setStatus(CommonEnums.FundTransferRequestStatus.INITIATED);
        model.setBeingChangedBy(whoChangedThis);
        fundTransferDal.createFundTransferInRequest(model);

    }

    public int saveFundTransferOutRequest(FundTransferRequestViewModel viewModel, Long whoChangedThis) {

        var userWallet=userWalletService.findByuserIdAndCurrencyCode(viewModel.getUserId(),viewModel.getCurrency());
        if(userWallet!=null) {
            if(userWallet.getActualBalance().compareTo(viewModel.getAmount())>=0) {
                var model = commonMapper.transmogrify(new FundTransferRequestModel(), viewModel);
                model.setDirection(CommonEnums.FundTransferDirection.IN);
                model.setStatus(CommonEnums.FundTransferRequestStatus.INITIATED);
                model.setBeingChangedBy(whoChangedThis);
              return   fundTransferDal.createFundTransferOutRequest(model);
            }
            else
            {
             return -1;
            }
        }
        else
        {
            return -2;
        }
    }


    public FundTransferRequestModel getFundTransferRequestbyId(Long id) {
        var model = repository.getById(id);
        return model;
    }

    public void aproveFundTransferInRequest(Long id, Long whoChangedThis) {
        fundTransferDal.approveFundTransferInRequest(id, whoChangedThis);
    }
    public void aproveFundTransferOutRequest(Long id, Long whoChangedThis) {
        fundTransferDal.approveFundTransferOutRequest(id, whoChangedThis);
    }
    public void rejectFundTransferInRequest(Long id, Long whoChangedThis)  {
        fundTransferDal.rejectFundTransferInRequest(id, whoChangedThis);
    }
    public void rejectFundTransferOutRequest(Long id, Long whoChangedThis)  {
        fundTransferDal.rejectFundTransferOutRequest(id, whoChangedThis);
    }

    public Page<FundTransferRequestModel> getPagebleRequest(Pageable pageable) {
        return repository.findAll(pageable);
    }

    public List<FundTransferRequestModel> getByUserId(Long userId) {
        return repository.findAllByUserId(userId);
    }
}
