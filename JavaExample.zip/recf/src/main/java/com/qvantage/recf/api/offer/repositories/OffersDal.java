package com.qvantage.recf.api.offer.repositories;

import com.qvantage.recf.api.offer.models.OfferModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class OffersDal {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Integer saveOfferRequest(OfferModel offerModel) {
        return jdbcTemplate.queryForObject(
                "select offerrequest(?, ?, ?, ?, ?)", Integer.class,
                offerModel.getUserId(),
                offerModel.getCampaignId(),
                offerModel.getCurrencyCode(),
                offerModel.getOfferedAmount(),
                offerModel.isAgreeToTerms()
        );

    }

    public BigDecimal getCampaignPendingAmount(Long campaignid) {
        return jdbcTemplate.queryForObject(
                "select (cpn.expectedamount- SUM(offeredamount)) as balanceamount from offers ofr inner join campaign cpn on ofr.campaignid=cpn.id\n" +
                        "where cpn.id =? and ofr.status =1 group by cpn.expectedamount", BigDecimal.class,
                campaignid
        );

    }

    public Integer rejectOfferRequest(Long offerId, Long adminUserId) {
        return jdbcTemplate.queryForObject(
                "select offersrequestreject(?, ?)", Integer.class,
                offerId,
                adminUserId
        );

    }
}
