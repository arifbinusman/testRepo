package com.qvantage.recf.api.file.services;

import com.qvantage.recf.api.file.models.FileModel;
import com.qvantage.recf.api.file.repositories.FileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Configurable
public class FileDBService {

    @Autowired
    FileRepository fileRepository;

    public Long saveFile(FileModel fileModel, Long whoChangedThis) {
        fileModel.setBeingChangedBy(whoChangedThis);
        fileRepository.save(fileModel);
        return fileModel.getId();
    }

    public FileModel getFileById(Long fileId) {
        FileModel fileModel = fileRepository.getFileById(fileId);
        return fileModel;
    }

    public List<FileModel> getByFileIdIn(Long[] fileids)
    {
        return fileRepository.findAllByIdIn(fileids);
    }
}
