package com.qvantage.recf.api.transactions.viewmodels;

import java.math.BigDecimal;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserWalletViewModel {

    private Long userId;
    private String currencyCode;
    private BigDecimal actualBalance;
    private BigDecimal ledgerBalance;
}
