package com.qvantage.recf.api.fundtransfer.repository;

import com.qvantage.recf.api.fundtransfer.models.FundTransferRequestModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;

@Repository
public class FundTransferDal {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Integer createFundTransferInRequest(FundTransferRequestModel fundTransferRequestModel) {
        return jdbcTemplate.queryForObject(
                "select * from fundtransferinrequest(?, ?, ?, ?, ?)", Integer.class,
                fundTransferRequestModel.getUserId(),
                fundTransferRequestModel.getAmount(),
                fundTransferRequestModel.getCurrency(),
                fundTransferRequestModel.getComment(),
                fundTransferRequestModel.getCreatedBy());
    }

    public Integer approveFundTransferInRequest(Long requestId, Long approvedBy) {
        return jdbcTemplate.queryForObject(
                "select * from  fundtransferinrequestapprove(?, ?)", Integer.class,
                requestId,
                approvedBy);
    }

    public Integer rejectFundTransferInRequest(Long requestId, Long approvedBy) {
        return jdbcTemplate.queryForObject(
                "select * from fundtransferinrequestreject(?, ?)", Integer.class,
                requestId,
                approvedBy);
    }

    public Integer createFundTransferOutRequest(FundTransferRequestModel fundTransferRequestModel) {
        return jdbcTemplate.queryForObject(
                "select fundTransferOutRequest(?, ?, ?, ?, ?)", Integer.class,
                fundTransferRequestModel.getUserId(),
                fundTransferRequestModel.getAmount(),
                fundTransferRequestModel.getCurrency(),
                fundTransferRequestModel.getComment(),
                fundTransferRequestModel.getCreatedBy());
    }

    public Integer approveFundTransferOutRequest(Long requestId, Long approvedBy) {
        return jdbcTemplate.queryForObject(
                "select * from  fundtransferoutrequestapprove(?, ?)", Integer.class,
                requestId,
                approvedBy);
    }
    public Integer rejectFundTransferOutRequest(Long requestId, Long approvedBy) {
        return jdbcTemplate.queryForObject(
                "select * from  fundtransferoutrequestreject(?, ?)", Integer.class,
                requestId,
                approvedBy);
    }
}
