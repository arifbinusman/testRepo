package com.qvantage.recf.api.usermgt.repositories;

import com.qvantage.recf.api.usermgt.models.RolesModel;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;
@Repository
public interface RolesRepository extends CrudRepository<RolesModel,Long> {
    @Query(value = "SELECT * FROM roles where name IN (:roles)", nativeQuery = true)
    Set<RolesModel> find(@Param("roles") List<String> roles);
}
