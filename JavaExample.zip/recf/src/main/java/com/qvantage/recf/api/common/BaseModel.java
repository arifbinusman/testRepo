package com.qvantage.recf.api.common;

import java.time.Instant;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@EqualsAndHashCode
@Getter
@MappedSuperclass
@Setter
@ToString
public class BaseModel {

    @Column(name = "id")
    @EqualsAndHashCode.Exclude
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;

    @Column(name = "isdeleted")
    private boolean isDeleted;

    @Column(name = "createdby")
    private Long createdBy;

    @Column(name = "createdat")
    @CreationTimestamp
    private Instant createdAt;

    @Column(name = "updatedby")
    private Long updatedBy;

    @Column(name = "updatedat")
    @UpdateTimestamp
    private Instant updatedAt;

    public void setBeingChangedBy(Long whom) {
        if (createdBy == null) {
            createdBy = whom;
        }
        updatedBy = whom;
    }
}
