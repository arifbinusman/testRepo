package com.qvantage.recf.api.campaign.services;

import com.qvantage.recf.api.campaign.models.PropertyModel;
import com.qvantage.recf.api.campaign.repositories.PropertyRepository;
import com.qvantage.recf.api.campaign.viewmodels.PropertySaveViewModel;
import com.qvantage.recf.api.campaign.viewmodels.PropertyViewModel;
import com.qvantage.recf.api.common.CommonMapper;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PropertyService {

    @Autowired
    private PropertyRepository repository;

    @Autowired
    private CommonMapper commonMapper;

    public Long save(PropertySaveViewModel viewModel, Long whoChangedThis) {
        var model = commonMapper.transmogrify(new PropertyModel(), viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return model.getId();
    }

    public List<PropertyViewModel> getAll() {
        var viewModelList = new ArrayList<PropertyViewModel>();
        for (var model : repository.findAllByIsDeleted(false)) {
            var viewModel = commonMapper.transmogrify(new PropertyViewModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }

    private PropertyModel getById(Long id) {
        var model = repository.findByIdAndIsDeleted(id, false);
        return model;
    }

    public PropertyViewModel get(Long id) {
        var model = getById(id);
        if (model == null) {
            return null;
        }
        var viewModel = commonMapper.transmogrify(new PropertyViewModel(), model);
        return viewModel;
    }

    public boolean update(PropertyViewModel viewModel, Long whoChangedThis) {
        var model = getById(viewModel.getId());
        if (model == null) {
            return false;
        }
        commonMapper.transmogrify(model, viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return true;
    }

    public boolean delete(Long id, Long whoChangedThis) {
        var model = getById(id);
        if (model == null) {
            return false;
        }
        model.setBeingChangedBy(whoChangedThis);
        model.setDeleted(true);
        repository.save(model);
        return true;
    }
}
