package com.qvantage.recf.api.common.models;

import com.qvantage.recf.api.common.BaseModel;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.vladmihalcea.hibernate.type.array.LongArrayType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "addresses")
@ToString(callSuper = true)
@TypeDefs({
        @TypeDef(
                name = "long-array",
                typeClass = LongArrayType.class
        )
})
public class AddressModel extends BaseModel {

    @Column(name = "userid")
    private Long userId;

    @Column(name = "addresstype")
    private Short addressType;

    @Column(name = "address1")
    private String address1;

    @Column(name = "address2")
    private String address2;

    @Column(name = "zipcode")
    private String zipCode;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "country")
    private String country;

    @Type( type = "long-array" )
    @Column(
            name = "fileids",
            columnDefinition = "Long[]"
    )
    private Long[] fileids;

    @Column(name = "isactive")
    private Boolean isActive;
}
