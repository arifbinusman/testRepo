package com.qvantage.recf.api.common.repositories;

import com.qvantage.recf.api.common.models.ContactModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;

@Repository
public interface ContactRepository extends CrudRepository<ContactModel, Long> {

    Iterable<ContactModel> findAllByIsDeleted(boolean isDeleted);
    Iterable<ContactModel> findAllByUserId(Long userId);
    ContactModel findByIdAndIsDeleted(Long id, boolean isDeleted);
    ContactModel findByIdAndUpdatedAt(Long id, Instant updatedAt);
}
