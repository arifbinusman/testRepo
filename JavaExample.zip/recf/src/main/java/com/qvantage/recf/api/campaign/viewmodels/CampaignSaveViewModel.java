package com.qvantage.recf.api.campaign.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
public class CampaignSaveViewModel {
    private Long propertyId;
    private String title;
    private String detailedDescription;
    private LocalDate launchDate;
    private LocalTime launchTime;
    private String additionalInfo;
    private BigDecimal expectedAmount;
    private BigDecimal finalAmount;
    private BigDecimal minInvestmentAmount;
    private BigDecimal investmentMultiple;
    private Short status;
    private Short validityInDays;
}
