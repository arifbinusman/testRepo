package com.qvantage.recf.api.usermgt.services;

import com.qvantage.recf.api.common.CommonEnums;
import com.qvantage.recf.api.common.CommonMapper;
import com.qvantage.recf.api.common.services.AddressService;
import com.qvantage.recf.api.common.services.ContactService;
import com.qvantage.recf.api.common.viewmodels.ContactSaveViewModel;
import com.qvantage.recf.api.usermgt.models.RolesModel;
import com.qvantage.recf.api.usermgt.models.UserModel;
import com.qvantage.recf.api.usermgt.repositories.RolesRepository;
import com.qvantage.recf.api.usermgt.repositories.UserRepository;
import com.qvantage.recf.api.usermgt.viewmodels.InvestorRegistrationStep1ViewModel;
import com.qvantage.recf.api.usermgt.viewmodels.UserStatusChangeViewModel;
import com.qvantage.recf.api.usermgt.viewmodels.UserViewModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service(value = "userService")
public class UserServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository repository;

    @Autowired
    private CommonMapper commonMapper;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private RolesRepository rolesRepository;

    @Autowired
    private UserDetailService userDetailService;

    @Autowired
    private ContactService contactService;

    @Autowired
    private UserIdentityService userIdentityService;

    @Autowired
    private AddressService addressService;

    @Override
    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
        UserModel user = repository.findByUserEmail(userId);
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username or password.");
        }
        Set<GrantedAuthority> grantedAuthorities = getAuthorities(user);
        return new org.springframework.security.core.userdetails.User(user.getId().toString(), user.getPassword(), grantedAuthorities);
    }

    private Set<GrantedAuthority> getAuthorities(UserModel user) {
        Set<RolesModel> roleByUserId = user.getRoles();
        final Set<GrantedAuthority> authorities = roleByUserId.stream().map(role -> new SimpleGrantedAuthority("ROLE_" + role.getName().toUpperCase())).collect(Collectors.toSet());
        return authorities;
    }

    public Long save(UserViewModel viewModel, Long whoChangedThis) {
        var model = commonMapper.transmogrify(new UserModel(), viewModel);
        model.setId(null);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return model.getId();
    }

    public Long saveInvestorStep1(InvestorRegistrationStep1ViewModel viewModel, Long whoChangedThis) {
        var model = commonMapper.transmogrify(new UserModel(), viewModel);
        model.setUserType((short) 1);
        model.setIsAccountLocked(false);
        model.setFailedLoginAttempts((short) 0);
        model.setIsEmailVerified(true);
        model.setIsTwoFARegistered((short) 1);
        model.setIsAgreeToTerms(true);
        model.setPassword(passwordEncoder.encode(viewModel.getPassword()));
        model.setBeingChangedBy(whoChangedThis);
        List<CommonEnums.RoleType> roleTypes = new ArrayList<>();
        viewModel.getRole().stream().map(role -> roleTypes.add(CommonEnums.RoleType.valueOf(role)));
        model.setRoles(rolesRepository.find(viewModel.getRole()));
        repository.save(model);
        var userDetailModel = commonMapper.mapUserDetails(viewModel);
        userDetailModel.setUserId(model.getId());
        userDetailService.saveUserDetails(userDetailModel);
        userDetailModel.setBeingChangedBy(whoChangedThis);
        ContactSaveViewModel contactSaveViewModel = new ContactSaveViewModel();
        contactSaveViewModel.setUserId(model.getId());
        contactSaveViewModel.setContactDetail(viewModel.getMobileNumber());
        contactSaveViewModel.setContactDetailType("Mobile");
        contactSaveViewModel.setIsPreferredMethod((short) 1);
        contactService.save(contactSaveViewModel, whoChangedThis);

        return model.getId();
    }

    public UserViewModel getUserDetails(Long userId) {
        var usermodel = repository.findByIdAndIsDeleted(userId, false);
        if (usermodel != null) {
            UserViewModel userViewModel = commonMapper.transmogrify(new UserViewModel(), usermodel);
            userViewModel.setDetail(userDetailService.getUserDetailById(userId));
            userViewModel.setIdentities(userIdentityService.getAllByUserId(userId));
            userViewModel.setAddressddresses(addressService.getByUserId(userId));
            userViewModel.setContacts(contactService.getAllByUserId(userId));
            return userViewModel;
        } else
            return null;
    }

    public boolean isUserEmailExists(String email) {
        var model = repository.findByUserEmail(email);
        return model != null;
    }

    public boolean updateUserStatus(UserStatusChangeViewModel userStatusChangeViewModel,Long whoChangedThis) {
        var userDetailModel = userDetailService.getUserDetailById(userStatusChangeViewModel.getUserId());
        if (userDetailModel != null) {
            userDetailModel.setAmlFinalStatus(userStatusChangeViewModel.getAmlStatus());
            userDetailModel.setUserStatus(userStatusChangeViewModel.getUserStatus());
            userDetailModel.setKycStatus(userStatusChangeViewModel.getKycStatus());
            userDetailModel.setBeingChangedBy(whoChangedThis);
            userDetailService.saveUserDetails(userDetailModel);
            return true;
        } else {
            return false;
        }
    }
}
