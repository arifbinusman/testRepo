package com.qvantage.recf.api.usermgt.viewmodels;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.qvantage.recf.api.common.CommonEnums;
import lombok.Data;


@Data
public class InvestorRegistrationStep1ViewModel {


    private String fullName;
    private String userName;
    private String userEmail;
    private String password;
    private Boolean isAgreeToTerms;
    private String mobileNumber;
    private LocalDate dateOfBirth;
    private String occupation;
    private String citizenship;
    private String currentResidentialCountry;
    private String sourceOfWealth;
    @JsonIgnore
    private List<String> role;

    public InvestorRegistrationStep1ViewModel() {
        role = new ArrayList<>();
        role.add(CommonEnums.RoleType.INVESTOR.toString());
    }
}
