package com.qvantage.recf.api.offer.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
public class MakeOfferViewModel {
    private Long campaignId;
    private Long userId;
    private BigDecimal offeredAmount;
    private boolean isAgreeToTerms;
    private String currencyCode;
}
