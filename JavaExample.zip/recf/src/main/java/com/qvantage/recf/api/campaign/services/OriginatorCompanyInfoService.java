package com.qvantage.recf.api.campaign.services;

import com.qvantage.recf.api.campaign.models.OriginatorCompanyInfoModel;
import com.qvantage.recf.api.campaign.repositories.OriginatorCompanyInfoRepository;
import com.qvantage.recf.api.campaign.viewmodels.OriginatorCompanyInfoSaveViewModel;
import com.qvantage.recf.api.campaign.viewmodels.OriginatorCompanyInfoViewModel;
import com.qvantage.recf.api.common.CommonMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class OriginatorCompanyInfoService {

    @Autowired
    private OriginatorCompanyInfoRepository repository;

    @Autowired
    private CommonMapper commonMapper;

    public Long save(OriginatorCompanyInfoSaveViewModel viewModel, Long whoChangedThis) {
        var model = commonMapper.transmogrify(new OriginatorCompanyInfoModel(), viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return model.getId();
    }

    public List<OriginatorCompanyInfoModel> getAll() {
        var viewModelList = new ArrayList<OriginatorCompanyInfoModel>();
        for (var model : repository.findAllByIsDeleted(false)) {
            var viewModel = commonMapper.transmogrify(new OriginatorCompanyInfoModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }
    public List<OriginatorCompanyInfoModel> getByUserId(Long userId) {
        var viewModelList = new ArrayList<OriginatorCompanyInfoModel>();
        for (var model : repository.findAllByUserId(userId)) {
            var viewModel = commonMapper.transmogrify(new OriginatorCompanyInfoModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }

    private OriginatorCompanyInfoModel getByIdAndUpdatedAt(Long id, Instant updatedAt) {
        var model = repository.findByIdAndUpdatedAt(id, updatedAt);
        return model;
    }

    private OriginatorCompanyInfoModel getById(Long id) {
        var model = repository.findByIdAndIsDeleted(id, false);
        return model;
    }

    public boolean update(OriginatorCompanyInfoViewModel viewModel, Long whoChangedThis) {
        var model = getByIdAndUpdatedAt(viewModel.getId(), viewModel.getUpdatedAt());
        if (model == null) {
            return false;
        }
        commonMapper.transmogrify(model, viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return true;
    }

    public boolean delete(Long id, Long whoChangedThis) {
        var model = getById(id);
        if (model == null) {
            return false;
        }
        model.setBeingChangedBy(whoChangedThis);
        model.setDeleted(true);
        repository.save(model);
        return true;
    }
}
