package com.qvantage.recf.api.offer.services;

import com.qvantage.recf.api.campaign.repositories.CampaignRepository;
import com.qvantage.recf.api.campaign.services.CampaignService;
import com.qvantage.recf.api.common.CommonEnums;
import com.qvantage.recf.api.common.CommonMapper;
import com.qvantage.recf.api.offer.models.OfferModel;
import com.qvantage.recf.api.offer.repositories.OfferRepository;
import com.qvantage.recf.api.offer.repositories.OffersDal;
import com.qvantage.recf.api.offer.viewmodels.MakeOfferViewModel;
import com.qvantage.recf.api.transactions.services.UserWalletService;
import com.qvantage.recf.api.usermgt.services.UserDetailService;
import com.qvantage.recf.api.usermgt.services.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

@Service
public class OfferService {

    @Autowired
    OfferRepository repository;

    @Autowired
    private CommonMapper commonMapper;

    @Autowired
    CampaignService campaignService;

    @Autowired
    UserDetailService userService;

    @Autowired
    OffersDal offersDal;

    @Autowired
    UserWalletService userWalletService;

    public Integer makeOffer(MakeOfferViewModel viewModel, Long whoChangedThis) {
        var user = userService.getUserDetailById(viewModel.getUserId());//max invest size
        if (user.getUserStatus() == CommonEnums.UserStatus.QUALIFIED) {
            var userWallet = userWalletService.findByuserIdAndCurrencyCode(viewModel.getUserId(), viewModel.getCurrencyCode());
            if (userWallet.getActualBalance().compareTo(viewModel.getOfferedAmount()) >= 0) {
                var campaign = campaignService.get(viewModel.getCampaignId());
                if (viewModel.getOfferedAmount().compareTo(campaign.getMinInvestmentAmount()) >= 0) {
                    if (viewModel.getOfferedAmount().remainder(campaign.getInvestmentMultiple()).compareTo(BigDecimal.ZERO) == 0) {
                        if (viewModel.getOfferedAmount().compareTo(campaign.getExpectedAmount()) <= 0) {
                            LocalDate datePart = LocalDate.parse(campaign.getLaunchDate().toString());
                            LocalTime timePart = LocalTime.parse(campaign.getLaunchTime().toString());
                            LocalDateTime dt = LocalDateTime.of(datePart, timePart);
                            if (dt.compareTo(LocalDateTime.now()) < 0) {
                                BigDecimal balanceAmount = offersDal.getCampaignPendingAmount(viewModel.getCampaignId());
                                if (viewModel.getOfferedAmount().compareTo(balanceAmount) <= 0) {
                                    var model = commonMapper.transmogrify(new OfferModel(), viewModel);
                                    model.setStatus(CommonEnums.OfferStatus.SUBMITTED);
                                    model.setBeingChangedBy(whoChangedThis);
                                    return offersDal.saveOfferRequest(model);
                                } else {
                                    return -5;
                                }

                            } else {
                                return -3;
                            }
                        } else {
                            return -5;
                        }
                    } else {
                        return -2;
                    }
                } else {
                    return -1;
                }
            } else {
                return -6;
            }
        } else {
            return -4;
        }
    }

    public boolean withdrawOffer(Long id, Long whoChangedThis) {
        offersDal.rejectOfferRequest(id, whoChangedThis);
        return true;
    }

    public boolean deleteOffer(Long id, Long whoChangedThis) {
        var model = getById(id);
        if (model == null) {
            return false;
        }
        model.setBeingChangedBy(whoChangedThis);
        model.setDeleted(true);
        repository.save(model);
        return true;
    }

    private OfferModel getById(Long id) {
        var model = repository.findByIdAndIsDeleted(id, false);
        return model;
    }
}
