package com.qvantage.recf.api.usermgt.services;

import org.springframework.stereotype.Service;

@Service
public class UserMgtValidationService {

}
