package com.qvantage.recf.api.usermgt.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
public class UserIdentityViewModel {

    private Long id;
    private Long userId;
    private Short idDocumentType;
    private String idNumber;
    private Short verificationStatus;
    private Long[] fileids;
    private Long updatedBy;
    private Instant updatedAt;
}
