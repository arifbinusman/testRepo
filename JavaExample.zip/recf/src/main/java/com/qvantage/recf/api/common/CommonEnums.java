package com.qvantage.recf.api.common;

public class CommonEnums {

    public static class KycStatus {

        public static final Short INITIATED = 1;
        public static final Short WIP = 2;
        public static final Short PASSED = 3;
    }
    public static class IdentityProofStatus {

        public static final Short UNVERIFIED = 1;
        public static final Short VERIFIED = 2;

    }

    public static class AMLStatus {

        public static final Short INITIATED = 1;
        public static final Short WIP = 2;
        public static final Short PASSED = 3;
    }
    public static class OfferStatus{
        public static final short SUBMITTED=1;
        public static final short ACCEPTED=2;
        public static final short REJECTED=3;
        public static final short WITHDRAWN=4;

    }
    public static class UserStatus{
        public static final short REGISTERED=1;
        public static final short VERIFICATIONPENDING=2;
        public static final short ACCREDATIONPENDING=3;
        public static final short QUALIFIED=4;
    }
    public static class RoleText{
        public static final String ROLE_ADMIN = "ROLE_ADMIN";
        public static final String ROLE_USER = "ROLE_INVESTOR";
    }
    public enum RoleType {

        ADMIN,INVESTOR
    }
    public static class FundTransferRequestStatus
    {
        public static final Short INITIATED = 1;
        public static final Short APPROVED = 2;
        public static final Short REJECTED = 3;
    }
    public static class FundTransferDirection
    {
        public static final Short IN=1;
        public static final Short OUT=2;
    }

}
