//package com.qvantage.recf.api.transactions.services;
//
//import com.qvantage.recf.api.common.viewmodels.JustErrorViewModel;
//import com.qvantage.recf.api.transactions.viewmodels.UserNewTransactionViewModel;
//import java.math.RoundingMode;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.stereotype.Service;
//
//@Service
//public class TransactionValidationService {
//
//    @Autowired
//    private JdbcTemplate jdbcTemplate;
//
//    public JustErrorViewModel validateTransactionPost(UserNewTransactionViewModel viewModel) {
//        if (viewModel.getUserId() == null) {
//            return new JustErrorViewModel("userId is required", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else if (viewModel.getCurrencyCode() == null) {
//            return new JustErrorViewModel("currencyCode is required", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else if (viewModel.getCreditAmount() == null && viewModel.getDebitAmount() == null) {
//            return new JustErrorViewModel("must specify creditAmount or debitAmount", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else if (viewModel.getCreditAmount() != null && viewModel.getDebitAmount() != null) {
//            return new JustErrorViewModel("cannot specify creditAmount and debitAmount", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else if (viewModel.getCreditAmount() != null && viewModel.getCreditAmount().signum() <= 0) {
//            return new JustErrorViewModel("creditAmount must be positive", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else if (viewModel.getCreditAmount() != null && viewModel.getCreditAmount().setScale(2, RoundingMode.FLOOR).compareTo(viewModel.getCreditAmount()) != 0) {
//            return new JustErrorViewModel("creditAmount cannot have more than 2 decimal places", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else if (viewModel.getDebitAmount() != null && viewModel.getDebitAmount().signum() <= 0) {
//            return new JustErrorViewModel("debitAmount must be positive", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else if (viewModel.getDebitAmount() != null && viewModel.getDebitAmount().setScale(2, RoundingMode.FLOOR).compareTo(viewModel.getDebitAmount()) != 0) {
//            return new JustErrorViewModel("debitAmount cannot have more than 2 decimal places", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else if (viewModel.getTransactionReference() == null) {
//            return new JustErrorViewModel("transactionReference is required", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else if (viewModel.getNarrationCode() == null) {
//            return new JustErrorViewModel("narrationCode is required", HttpStatus.UNPROCESSABLE_ENTITY);
//        } else {
//            var existences = jdbcTemplate.queryForList("values " +
//                    "(exists(select null from users where id = ? and isdeleted is false)), " +
//                    "(exists(select null from currencies where currencycode = ?)), " +
//                    "(exists(select null from transactionnarrations where narrationcode = ?)), " +
//                    "(exists(select null from usertransactions where transactionreference = ?))", Boolean.class, viewModel.getUserId(), viewModel.getCurrencyCode(), viewModel.getNarrationCode(), viewModel.getTransactionReference());
//            if (!existences.get(0)) {
//                return new JustErrorViewModel("userId is not found", HttpStatus.NOT_FOUND);
//            } else if (!existences.get(1)) {
//                return new JustErrorViewModel("currencyCode is not found", HttpStatus.NOT_FOUND);
//            } else if (!existences.get(2)) {
//                return new JustErrorViewModel("narrationCode is not found", HttpStatus.NOT_FOUND);
//            } else if (existences.get(3)) {
//                return new JustErrorViewModel("transactionReference already exists", HttpStatus.UNPROCESSABLE_ENTITY);
//            }
//        }
//        return null;
//    }
//}
