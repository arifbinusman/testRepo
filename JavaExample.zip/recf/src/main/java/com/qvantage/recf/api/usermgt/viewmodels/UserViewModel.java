package com.qvantage.recf.api.usermgt.viewmodels;

import java.time.LocalDate;
import java.util.List;

import com.qvantage.recf.api.common.viewmodels.AddressViewModel;
import com.qvantage.recf.api.common.viewmodels.ContactViewModel;
import com.qvantage.recf.api.usermgt.models.UserDetailModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserViewModel {


    private Short userType;
    private String userName;
    private String userEmail;
    private String fullName;
    private Boolean isAgreeToTerms;
    private Boolean isEmailVerified;
    private Short isTwoFARegistered;
    private Boolean isAccountLocked;
    private Short failedLoginAttempts;
    private UserDetailModel detail;
    private List<UserIdentityViewModel> identities;
    private List<AddressViewModel> addressddresses;
    private List<ContactViewModel> contacts;

}
