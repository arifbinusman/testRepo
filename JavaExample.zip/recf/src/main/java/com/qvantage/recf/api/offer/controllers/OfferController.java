package com.qvantage.recf.api.offer.controllers;

import com.amazonaws.services.xray.model.Http;
import com.qvantage.recf.api.common.services.WhoChangedThingsService;
import com.qvantage.recf.api.common.viewmodels.JustIdViewModel;
import com.qvantage.recf.api.offer.services.OfferService;
import com.qvantage.recf.api.offer.viewmodels.MakeOfferViewModel;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Log4j2
@RestController
@RequestMapping("/api/v1")
public class OfferController {
    @Autowired
    OfferService offerService;

    @Autowired
    WhoChangedThingsService whoChangedThingsService;

    @PostMapping("/offer/create")
    public ResponseEntity<?> createOffer(MakeOfferViewModel viewModel) {
        log.info("Make Offer : " + viewModel);
        var newId = offerService.makeOffer(viewModel, whoChangedThingsService.getWho());
        if (newId > 0) {
            return new ResponseEntity<>(HttpStatus.ACCEPTED);
        } else
            return new ResponseEntity<>(getOfferErrorMessages(newId), HttpStatus.BAD_REQUEST);
    }

    private String getOfferErrorMessages(Integer code) {
        String errorMessage = "";
        switch (code) {
            case -1:
                errorMessage = "Investment amount is less than minimum investment amount.";
                break;
            case -2:
                errorMessage = "Investment amount is not multiple of investment multiple amount";
                break;
            case -3:
                errorMessage = "Campaign is not launched yet or its expired.";
                break;
            case -4:
                errorMessage = "Your account is not approved by admin to make an investment.";
                break;
            case -5:
                errorMessage = "You cannot invest more than total campaign amount.";
                break;
            case  -6:
                errorMessage="You do not have sufficient amount in your wallet to make this investment.";
                break;
                default:
                    errorMessage="Something went wrong";

        }
        return errorMessage;
    }

    @DeleteMapping("/offer/withdraw/{id}")
    public ResponseEntity<?> withDrawOffer(@PathVariable Long id) {
        log.info("withdraw offer :" + id);
        if (!offerService.withdrawOffer(id, whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
