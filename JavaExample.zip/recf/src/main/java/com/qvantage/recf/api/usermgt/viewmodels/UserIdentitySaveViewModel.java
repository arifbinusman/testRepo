package com.qvantage.recf.api.usermgt.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserIdentitySaveViewModel {

    private Long userId;
    private Short idDocumentType;
    private String idNumber;
    private Long[] fileids;
}
