package com.qvantage.recf.api.usermgt.models;

import com.qvantage.recf.api.common.BaseModel;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.vladmihalcea.hibernate.type.array.LongArrayType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "useridentities")
@ToString(callSuper = true)
@TypeDefs({
        @TypeDef(
                name = "long-array",
                typeClass = LongArrayType.class
        )
})
public class UserIdentityModel extends BaseModel {

    @Column(name = "userid")
    private Long userId;

    @Column(name = "iddocumenttype")
    private Short idDocumentType;

    @Column(name = "idnumber")
    private String idNumber;

    @Column(name = "verificationstatus")
    private Short verificationStatus;
    @Type( type = "long-array" )
    @Column(
            name = "fileids",
            columnDefinition = "Long[]"
    )
    private Long[] fileids;
}
