//package com.qvantage.recf.api.transactions.controllers;
//
//import com.qvantage.recf.api.common.services.WhoChangedThingsService;
//import com.qvantage.recf.api.common.viewmodels.JustErrorViewModel;
//import com.qvantage.recf.api.common.viewmodels.JustIdViewModel;
//import com.qvantage.recf.api.transactions.repositories.DataAccessLayer;
//import com.qvantage.recf.api.transactions.services.TransactionValidationService;
//import com.qvantage.recf.api.transactions.services.UserTransactionService;
//import com.qvantage.recf.api.transactions.viewmodels.UserNewTransactionViewModel;
//import java.time.LocalDate;
//import java.time.ZoneId;
//import lombok.extern.log4j.Log4j2;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort.Direction;
//import org.springframework.data.web.SortDefault;
//import org.springframework.format.annotation.DateTimeFormat;
//import org.springframework.format.annotation.DateTimeFormat.ISO;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//@Log4j2
//@RestController
//@RequestMapping("/api/v1")
//public class TransactionController {
//
//    private static final ZoneId ZONEID_UTC = ZoneId.of("Z");
//
//    @Autowired
//    WhoChangedThingsService whoChangedThingsService;
//
//    @Autowired
//    private UserTransactionService userTransactionService;
//
//    @Autowired
//    private TransactionValidationService transactionValidationService;
//
//    @Autowired
//    private DataAccessLayer dataAccessLayer;
//
//    @GetMapping("/transaction/{userId}/{currencyCode}")
//    public Object getTransaction(@PathVariable Long userId, @PathVariable String currencyCode, @RequestParam @DateTimeFormat(iso = ISO.DATE) LocalDate startDate, @RequestParam @DateTimeFormat(iso = ISO.DATE) LocalDate endDate, @SortDefault(sort = "createdAt", direction = Direction.DESC) Pageable pageable) {
//        var startTime = startDate.atStartOfDay(ZONEID_UTC).toInstant();
//        var endTimeExclusive = endDate.plusDays(1).atStartOfDay(ZONEID_UTC).toInstant();
//        return ResponseEntity.ok(userTransactionService.getPageByEverything(userId, currencyCode, startTime, endTimeExclusive, pageable));
//    }
//
//    @PostMapping("/transaction")
//    public Object postTransaction(@RequestBody UserNewTransactionViewModel viewModel) {
//        JustErrorViewModel errorViewModel = transactionValidationService.validateTransactionPost(viewModel);
//
//        if (errorViewModel == null) {
//            log.info("Saving Transaction: " + viewModel);
//            var newId = dataAccessLayer.createApprovedTransaction(viewModel, whoChangedThingsService.getWho());
//            return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
//        } else {
//            log.info("Not saving Transaction because " + errorViewModel.getError() + ": " + viewModel);
//            return new ResponseEntity<>(errorViewModel, errorViewModel.getStatus());
//        }
//    }
//
//}
