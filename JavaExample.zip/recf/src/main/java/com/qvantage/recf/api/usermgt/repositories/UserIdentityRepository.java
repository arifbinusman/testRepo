package com.qvantage.recf.api.usermgt.repositories;

import com.qvantage.recf.api.usermgt.models.UserIdentityModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;

@Repository
public interface UserIdentityRepository extends CrudRepository<UserIdentityModel, Long> {

    Iterable<UserIdentityModel> findAllByIsDeleted(boolean isDeleted);

    UserIdentityModel findByIdAndIsDeleted(Long id, boolean isDeleted);
    UserIdentityModel findByIdAndUpdatedAt(Long id, Instant updatedAt);
    Iterable<UserIdentityModel> findAllByUserId(Long userId);
}
