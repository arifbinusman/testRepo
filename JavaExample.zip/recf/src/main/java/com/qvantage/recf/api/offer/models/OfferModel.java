package com.qvantage.recf.api.offer.models;

import com.qvantage.recf.api.common.BaseModel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "offers")
@ToString(callSuper = true)
public class OfferModel extends BaseModel {

    @Column(name = "campaignid")
    private Long campaignId;

    @Column(name = "userid")
    private Long userId;

    @Column(name = "offeredamount")
    private BigDecimal offeredAmount;

    @Column(name = "acceptedamount")
    private BigDecimal acceptedAmount;

    @Column(name = "isagreetoterms")
    private boolean isAgreeToTerms;

    @Column(name = "status")
    private short status;

    @Column(name = "currencycode")
    private String currencyCode;
}
