package com.qvantage.recf.api.usermgt.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.qvantage.recf.api.common.BaseModel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "userdetail")
@ToString(callSuper = true)
public class UserDetailModel extends BaseModel {

    @Column(name = "userid")
    private Long userId;

    @Column(name = "occupation")
    private String occupation;

    @JsonIgnore
    @Column(name = "idcardnumber")
    private String idCardNumber;

    @Column(name = "dateofbirth")
    private LocalDate dateOfBirth;

    @Column(name = "accountsource")
    private Short accountSource;

    @Column(name = "sourceofwealth")
    private String sourceOfWealth;

    @Column(name = "kycstatus")
    private Short kycStatus;

    @Column(name = "userstatus")
    private Short userStatus;

    @Column(name = "amlfinalstatus")
    private Short amlFinalStatus;

    @Column(name = "citizenship")
    private String citizenShip;

    @Column(name = "countryofresident")
    private String countryOfResident;
}
