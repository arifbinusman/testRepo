package com.qvantage.recf.api.usermgt.services;

import com.qvantage.recf.api.common.CommonEnums;
import com.qvantage.recf.api.common.CommonMapper;
import com.qvantage.recf.api.usermgt.models.UserIdentityModel;
import com.qvantage.recf.api.usermgt.repositories.UserIdentityRepository;
import com.qvantage.recf.api.usermgt.viewmodels.UserIdentitySaveViewModel;
import com.qvantage.recf.api.usermgt.viewmodels.UserIdentityViewModel;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserIdentityService {

    @Autowired
    private UserIdentityRepository repository;

    @Autowired
    private CommonMapper commonMapper;

    public Long save(UserIdentitySaveViewModel viewModel, Long whoChangedThis) {
        var model = commonMapper.transmogrify(new UserIdentityModel(), viewModel);
        model.setBeingChangedBy(whoChangedThis);
        model.setVerificationStatus(CommonEnums.IdentityProofStatus.UNVERIFIED);
        repository.save(model);
        return model.getId();
    }

    public List<UserIdentityViewModel> getAll() {
        var viewModelList = new ArrayList<UserIdentityViewModel>();
        for (var model : repository.findAllByIsDeleted(false)) {
            var viewModel = commonMapper.transmogrify(new UserIdentityViewModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }

    private UserIdentityModel getById(Long id) {
        var model = repository.findByIdAndIsDeleted(id, false);
        return model;
    }

    private UserIdentityModel getByIdAndUpdatedAt(Long id, Instant updatedAt) {
        var model = repository.findByIdAndUpdatedAt(id, updatedAt);
        return model;
    }

    public List<UserIdentityViewModel> getAllByUserId(Long userId) {
        var viewModelList = new ArrayList<UserIdentityViewModel>();
        for (var model : repository.findAllByUserId(userId)) {
            var viewModel = commonMapper.transmogrify(new UserIdentityViewModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }

    public UserIdentityViewModel get(Long id) {
        var model = getById(id);
        if (model == null) {
            return null;
        }
        var viewModel = commonMapper.transmogrify(new UserIdentityViewModel(), model);
        return viewModel;
    }

    public boolean update(UserIdentityViewModel viewModel, Long whoChangedThis) {
        var model = getByIdAndUpdatedAt(viewModel.getId(), viewModel.getUpdatedAt());
        if (model == null) {
            return false;
        }
        commonMapper.transmogrify(model, viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return true;
    }

    public boolean delete(Long id, Long whoChangedThis) {
        var model = getById(id);
        if (model == null) {
            return false;
        }
        model.setBeingChangedBy(whoChangedThis);
        model.setDeleted(true);
        repository.save(model);
        return true;
    }
}
