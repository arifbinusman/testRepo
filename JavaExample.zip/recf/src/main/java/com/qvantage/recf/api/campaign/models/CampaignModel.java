package com.qvantage.recf.api.campaign.models;

import com.qvantage.recf.api.common.BaseModel;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "campaign")
@ToString(callSuper = true)
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class CampaignModel extends BaseModel {

    @Column(name = "propertyid")
    private Long propertyId;

    @Column(name = "title")
    private String title;

    @Column(name = "detaileddescription")
    private String detailedDescription;

    @Column(name = "launchdate")
    private LocalDate launchDate;

    @Column(name = "launchtime")
    private LocalTime launchTime;

    @Column(name = "expectedamount")
    private BigDecimal expectedAmount;

    @Column(name = "finalamount")
    private BigDecimal finalAmount;

    @Column(name = "mininvestmentamount")
    private BigDecimal minInvestmentAmount;

    @Column(name = "investmentmultiple")
    private BigDecimal investmentMultiple;

    @Column(name = "validityindays")
    private Short validityInDays;

    @Column(name = "status")
    private Short status;

}
