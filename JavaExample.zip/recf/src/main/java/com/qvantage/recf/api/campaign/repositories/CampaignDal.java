package com.qvantage.recf.api.campaign.repositories;

import com.qvantage.recf.api.campaign.rowmappers.CampaignListRowMapper;
import com.qvantage.recf.api.campaign.viewmodels.CampaignListViewModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class CampaignDal {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<CampaignListViewModel> getCampaigns(String country)
    {
        String query = "select p.id as propertyid ,c.id as campaignid, p.propertytype,p.address,p.city,p.state,p.country,p.zipcode,p.investmentperiod,p.initialgrosspropertyyieldpa,p.annualisedcashyield,p.annualisedreturn,p.thumbnailfileids,c.expectedamount,(SELECT SUM(o.offeredamount) from offers o where o.campaignid=c.id) as fundedAmount\n" +
                ",c.mininvestmentamount , p.assetprice , p.currency\n" +
                "from properties p inner join campaign c on p.id=c.propertyid\n" +
                "where p.isdeleted=false and c.isdeleted=false and c.status=2 and p.country=?" ;
        List<CampaignListViewModel> lstCampaignListViewModel = jdbcTemplate.query(query ,new Object[] {country},new CampaignListRowMapper());

        return lstCampaignListViewModel;
    }
}
