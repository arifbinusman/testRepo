package com.qvantage.recf.api.common.viewmodels;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class JustErrorViewModel {

    private String error;
    @JsonIgnore
    private HttpStatus status;
}
