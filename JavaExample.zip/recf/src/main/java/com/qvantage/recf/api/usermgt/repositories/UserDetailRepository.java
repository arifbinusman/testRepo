package com.qvantage.recf.api.usermgt.repositories;

import com.qvantage.recf.api.usermgt.models.UserDetailModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDetailRepository extends CrudRepository<UserDetailModel, Long> {
    UserDetailModel findByUserId(Long userId);
}
