package com.qvantage.recf.api.file.models;

import com.qvantage.recf.api.common.BaseModel;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "files")
@ToString(callSuper = true)
public class FileModel extends BaseModel {

    @Column(name = "filename")
    private String fileName;

    @Column(name = "fileextension")
    private String fileExtension;

    @Column(name = "filedoctype")
    private String fileDocType;

    @Column(name = "filefullpath")
    private String fileFullPath;

    @Column(name = "actualfilename")
    private String actualFileName;


    @Column(name = "filesize")
    private Long fileSize;


    @Column(name = "filechecksum")
    private String fileChecksum;

    @Transient
    private byte[] fileContent;
}
