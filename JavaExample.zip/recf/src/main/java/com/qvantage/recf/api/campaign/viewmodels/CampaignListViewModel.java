package com.qvantage.recf.api.campaign.viewmodels;



import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
public class CampaignListViewModel {
    private Long propertyid;
    private Long campaignid;
    private Short propertyType;
    private String address;
    private String city;
    private String state;
    private String country;
    private String zipCode;
    private Short investmentPeriod;
    private BigDecimal initialGrossPropertyYieldpa;
    private BigDecimal annualisedCashYield;
    private BigDecimal annualisedReturn;
    private List<String> thumbnailImageUrls;
    @JsonIgnore
    private Long[] fileids;
    private BigDecimal expectedAmount;
    private BigDecimal fundedAmount;
    private BigDecimal miniumInvestmentAmount;
    private BigDecimal assetPrice;
    private String currency;
}
