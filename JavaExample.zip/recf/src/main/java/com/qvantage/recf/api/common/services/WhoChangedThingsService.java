package com.qvantage.recf.api.common.services;

import org.springframework.stereotype.Service;
import java.security.Principal;
@Service
public class WhoChangedThingsService {

    public Long getWho() {


        return -1L;
    }
}
