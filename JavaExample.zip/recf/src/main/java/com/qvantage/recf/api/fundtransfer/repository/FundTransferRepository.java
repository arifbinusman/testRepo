package com.qvantage.recf.api.fundtransfer.repository;

import com.qvantage.recf.api.fundtransfer.models.FundTransferRequestModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.time.Instant;
import java.util.List;

@Repository
public interface FundTransferRepository extends PagingAndSortingRepository<FundTransferRequestModel,Long> {
    FundTransferRequestModel getFundTransferRequestModelByIdAndUpdatedAt(Long id, Instant updateAt);
    FundTransferRequestModel getById(Long id);
    Page<FundTransferRequestModel> findAll(Pageable pageable);
    List<FundTransferRequestModel> findAllByUserId(Long userId);

}

