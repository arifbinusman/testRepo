package com.qvantage.recf.api.campaign.repositories;

import com.qvantage.recf.api.campaign.models.OriginatorCompanyOfficerModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;

@Repository
public interface OriginatorCompanyOfficerRepository extends CrudRepository<OriginatorCompanyOfficerModel, Long> {

    Iterable<OriginatorCompanyOfficerModel> findAllByIsDeleted(boolean isDeleted);

    OriginatorCompanyOfficerModel findByIdAndIsDeleted(Long id, boolean isDeleted);

    Iterable<OriginatorCompanyOfficerModel> findByCompanyIdAndIsDeleted(Long companyId, boolean isDeleted);

    OriginatorCompanyOfficerModel findByIdAndUpdatedAt(Long id, Instant updatedAt);
}
