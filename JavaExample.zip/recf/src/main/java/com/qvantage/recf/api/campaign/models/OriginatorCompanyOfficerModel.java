package com.qvantage.recf.api.campaign.models;

import com.qvantage.recf.api.common.BaseModel;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "originatorcompanyofficers")
@ToString(callSuper = true)
public class OriginatorCompanyOfficerModel extends BaseModel {

    @Column(name = "companyid")
    private Long companyId;

    @Column(name = "offname")
    private String offName;

    @Column(name = "offtype")
    private String offType;

    @Column(name = "offadditionalinfo")
    private String offAdditionalInfo;
}
