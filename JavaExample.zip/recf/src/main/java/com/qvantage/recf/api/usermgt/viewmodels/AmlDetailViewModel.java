package com.qvantage.recf.api.usermgt.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
public class AmlDetailViewModel {

    private Long id;
    private Long userId;
    private String amlSearchType;
    private String amlSearchResult;
    private String amlSearchComments;
    private Short amlStatus;
    private Long updatedBy;
    private Instant updatedAt;
}
