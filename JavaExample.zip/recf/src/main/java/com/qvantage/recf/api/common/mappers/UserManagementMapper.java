package com.qvantage.recf.api.common.mappers;

import com.qvantage.recf.api.usermgt.models.UserModel;
import com.qvantage.recf.api.usermgt.viewmodels.UserViewModel;
import lombok.SneakyThrows;
import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.stereotype.Service;

@Service
public class UserManagementMapper {

    @SneakyThrows
    public UserModel getUserModel(UserViewModel source) {
        UserModel target = new UserModel();
        PropertyUtils.copyProperties(target, source);
        return target;
    }

    @SneakyThrows
    public UserViewModel getUserViewModel(UserModel source) {
        UserViewModel target = new UserViewModel();
        PropertyUtils.copyProperties(target, source);
        return target;
    }

}
