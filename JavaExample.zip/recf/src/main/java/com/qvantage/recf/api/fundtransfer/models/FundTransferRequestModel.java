package com.qvantage.recf.api.fundtransfer.models;

import com.qvantage.recf.api.common.BaseModel;
import com.vladmihalcea.hibernate.type.array.LongArrayType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "fundtransferrequest")
@ToString(callSuper = true)
@TypeDefs({
        @TypeDef(
                name = "long-array",
                typeClass = LongArrayType.class
        )
})
public class FundTransferRequestModel extends BaseModel {

    @Column(name = "userid")
    private long userId;

    @Column(name = "amount")
    private BigDecimal amount;

    @Column(name = "comment")
    private String comment;

    @Column(name = "status")
    private Short status;

    @Column(name = "currencycode")
    private String currency;

    @Column(name = "direction")
    private Short direction;
    @Type( type = "long-array" )
    @Column(
            name = "fileids",
            columnDefinition = "Long[]"
    )
    private Long[] fileids;

}
