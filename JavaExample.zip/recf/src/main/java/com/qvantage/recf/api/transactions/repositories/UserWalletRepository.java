package com.qvantage.recf.api.transactions.repositories;

import com.qvantage.recf.api.transactions.models.UserWalletModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public interface UserWalletRepository extends CrudRepository<UserWalletModel, Long> {

    Iterable<UserWalletModel> findAllByUserId(Long userId);

    UserWalletModel findByUserIdAndCurrencyCode (Long userId,String currencyCode);
}
