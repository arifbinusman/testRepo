package com.qvantage.recf.api.usermgt.controllers;

import com.qvantage.recf.api.common.APIErrorMessage;
import com.qvantage.recf.api.common.services.WhoChangedThingsService;
import com.qvantage.recf.api.common.viewmodels.JustIdViewModel;
import com.qvantage.recf.api.usermgt.services.AmlDetailService;
import com.qvantage.recf.api.usermgt.services.UserIdentityService;
import com.qvantage.recf.api.usermgt.services.UserServiceImpl;
import com.qvantage.recf.api.usermgt.viewmodels.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Log4j2
@RestController
@RequestMapping("/api/v1")
public class UserMgtController {

    @Autowired
    AmlDetailService amlDetailService;

    @Autowired
    UserServiceImpl userServiceImpl;

    @Autowired
    UserIdentityService userIdentityService;

    @Autowired
    WhoChangedThingsService whoChangedThingsService;

    @PostMapping("/user/aml")
    public ResponseEntity<?> saveAmlDetail(@RequestBody AmlSaveViewModel viewModel) {
        log.info("Saving AmlDetail Registration: " + viewModel);
        var newId = amlDetailService.save(viewModel, whoChangedThingsService.getWho());
        return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
    }

    @GetMapping("/user/aml")
    public ResponseEntity<?> getAllAmlDetails() {
        return new ResponseEntity<>(amlDetailService.getAll(), HttpStatus.OK);
    }


    @GetMapping("/user/aml/{userid}")
    public ResponseEntity<?> getAmlDetailByUserId(@PathVariable Long userid) {
        var viewModel = amlDetailService.getByUserId(userid);
        if (viewModel == null) {
            return new ResponseEntity<>(new APIErrorMessage("No records found."), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(viewModel, HttpStatus.OK);
    }

    @PutMapping("/user/aml/{id}")
    public ResponseEntity<?> updateAmlDetail(@PathVariable Long id, @RequestBody AmlDetailViewModel viewModel) {
        viewModel.setId(id);
        log.info("Updating AmlDetail Registration: " + viewModel);
        if (!amlDetailService.update(viewModel, whoChangedThingsService.getWho())) {
            return new ResponseEntity<>(new APIErrorMessage("No records found."), HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @DeleteMapping("/user/aml/{id}")
    public ResponseEntity<?> deleteAmlDetail(@PathVariable Long id) {
        log.info("Deleting AmlDetail Registration ID: " + id);
        if (!amlDetailService.delete(id, whoChangedThingsService.getWho())) {
            return new ResponseEntity<>(new APIErrorMessage("No records found."), HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @PostMapping("/user")
    public ResponseEntity<?> saveUser(@RequestBody UserViewModel viewModel) {
        log.info("Saving User Registration: " + viewModel);
        var newId = userServiceImpl.save(viewModel, whoChangedThingsService.getWho());
        return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
    }

    @PostMapping("/user/registration/step1")
    public ResponseEntity<?> saveUser(@RequestBody InvestorRegistrationStep1ViewModel viewModel) {
        log.info("Saving investors Registration step1: " + viewModel);
        if (!userServiceImpl.isUserEmailExists(viewModel.getUserEmail())) {
            var newId = userServiceImpl.saveInvestorStep1(viewModel, whoChangedThingsService.getWho());
            return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(new APIErrorMessage("Email address already exists"), HttpStatus.CONFLICT);
        }
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<?> getUserDetails(@PathVariable Long id) {

        log.info("getting user by user details" + id);
        var uservm = userServiceImpl.getUserDetails(id);
        if (uservm != null) {
            return new ResponseEntity<>(uservm, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(new APIErrorMessage("No records found."), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/user/identity")
    public ResponseEntity<?> saveUserIdentity(@RequestBody UserIdentitySaveViewModel viewModel) {
        log.info("Saving UserIdentity Registration: " + viewModel);
        var newId = userIdentityService.save(viewModel, whoChangedThingsService.getWho());
        return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
    }

    @GetMapping("/user/identity")
    public ResponseEntity<?> getAllUserIdentitys() {
        return new ResponseEntity<>(userIdentityService.getAll(), HttpStatus.OK);
    }

    @GetMapping("/user/identity/{userid}")
    public ResponseEntity<?> getUserIdentity(@PathVariable Long userid) {
        var viewModel = userIdentityService.getAllByUserId(userid);
        if (viewModel == null) {
            return new ResponseEntity<>(new APIErrorMessage("No records found."), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(viewModel, HttpStatus.OK);
    }

    @PutMapping("/user/identity/{id}")
    public ResponseEntity<?> updateUserIdentity(@PathVariable Long id, @RequestBody UserIdentityViewModel viewModel) {
        viewModel.setId(id);
        log.info("Updating UserIdentity Registration: " + viewModel);
        if (!userIdentityService.update(viewModel, whoChangedThingsService.getWho())) {
            return new ResponseEntity<>(new APIErrorMessage("No records found."), HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @PutMapping("/user/status/{userid}")
    public ResponseEntity<?> changeUserStatus(@PathVariable Long userid, @RequestBody UserStatusChangeViewModel userStatusChangeViewModel) {
        log.info("changing user status" + userStatusChangeViewModel);
        if (userServiceImpl.updateUserStatus(userStatusChangeViewModel,whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        } else {
            return new ResponseEntity<>(new APIErrorMessage("No records found."), HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/user/identity/{id}")
    public ResponseEntity<?> deleteUserIdentity(@PathVariable Long id) {
        log.info("Deleting UserIdentity Registration ID: " + id);
        if (!userIdentityService.delete(id, whoChangedThingsService.getWho())) {
            return new ResponseEntity<>(new APIErrorMessage("No records found."), HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @GetMapping("/user/checkemailexists/{email}")
    public ResponseEntity<Boolean> checkUserEmailExists(@PathVariable String email) {
        log.info("Checking user email exists: " + email);
        return new ResponseEntity<>(userServiceImpl.isUserEmailExists(email), HttpStatus.OK);
    }
}

