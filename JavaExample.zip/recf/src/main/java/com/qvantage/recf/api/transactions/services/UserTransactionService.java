//package com.qvantage.recf.api.transactions.services;
//
//import com.qvantage.recf.api.common.CommonMapper;
//import com.qvantage.recf.api.transactions.repositories.UserTransactionRepository;
//import com.qvantage.recf.api.transactions.viewmodels.UserTransactionViewModel;
//import java.time.Instant;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.Pageable;
//import org.springframework.stereotype.Service;
//
//@Service
//public class UserTransactionService {
//
//    @Autowired
//    private UserTransactionRepository repository;
//
//    @Autowired
//    private CommonMapper commonMapper;
//
//    public Page<UserTransactionViewModel> getPageByEverything(Long userId, String currencyCode, Instant startTime, Instant endTimeExclusive, Pageable pageable) {
//        return repository.findAllByUserIdAndCurrencyCodeAndCreatedAtGreaterThanEqualAndCreatedAtLessThan(userId, currencyCode, startTime, endTimeExclusive, pageable).map(model -> {
//            var viewModel = commonMapper.transmogrify(new UserTransactionViewModel(), model);
//            viewModel.setPreviousLedgerBalance(model.getPreviousLedgerBalance());
//            viewModel.setCreditAmount(model.getCreditAmount().signum() > 0 ? model.getCreditAmount() : null);
//            viewModel.setDebitAmount(model.getCreditAmount().signum() < 0 ? model.getCreditAmount().negate() : null);
//            viewModel.setUpdatedLedgerBalance(model.getPreviousLedgerBalance().add(model.getCreditAmount()));
//            return viewModel;
//        });
//    }
//}
