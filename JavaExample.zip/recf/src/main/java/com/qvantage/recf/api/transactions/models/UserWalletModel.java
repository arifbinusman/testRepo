package com.qvantage.recf.api.transactions.models;

import java.math.BigDecimal;
import java.time.Instant;
import javax.persistence.*;

import com.qvantage.recf.api.common.BaseModel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@EqualsAndHashCode
@Getter
@Setter
@Table(name = "wallet")
@ToString
public class UserWalletModel {

    @EqualsAndHashCode.Exclude
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;

    @Column(name = "createdby")
    private Long createdBy;

    @Column(name = "createdat")
    @CreationTimestamp
    private Instant createdAt;

    @Column(name = "updatedby")
    private Long updatedBy;

    @Column(name = "updatedat")
    @UpdateTimestamp
    private Instant updatedAt;

    @Column(name = "userid")
    private Long userId;

    @Column(name = "currencycode")
    private String currencyCode;

    @Column(name = "actualbalance")
    private BigDecimal actualBalance;

    @Column(name = "ledgerbalance")
    private BigDecimal ledgerBalance;

}
