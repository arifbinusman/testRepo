package com.qvantage.recf.api.usermgt.services;

import com.qvantage.recf.api.usermgt.models.UserDetailModel;
import com.qvantage.recf.api.usermgt.repositories.UserDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserDetailService {

    @Autowired
    UserDetailRepository repository;

    public UserDetailModel getUserDetailById(Long userid) {
        return repository.findByUserId(userid);
    }

    public Long saveUserDetails(UserDetailModel model)
    {
        repository.save(model);
        return model.getId();
    }
}
