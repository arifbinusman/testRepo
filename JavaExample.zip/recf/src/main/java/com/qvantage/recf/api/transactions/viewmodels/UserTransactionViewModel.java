//package com.qvantage.recf.api.transactions.viewmodels;
//
//import java.math.BigDecimal;
//import java.time.Instant;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//public class UserTransactionViewModel {
//
//    private Long id;
//    private Long userId;
//    private String currencyCode;
//    private BigDecimal previousLedgerBalance;
//    private BigDecimal creditAmount;
//    private BigDecimal debitAmount;
//    private BigDecimal updatedLedgerBalance;
//    private String transactionReference;
//    private String narrationCode;
//    private Instant createdAt;
//}
