package com.qvantage.recf.api.common.controllers;

import com.qvantage.recf.api.common.services.AddressService;
import com.qvantage.recf.api.common.services.ContactService;
import com.qvantage.recf.api.common.services.WhoChangedThingsService;
import com.qvantage.recf.api.common.viewmodels.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Log4j2
@RestController
@RequestMapping("/api/v1")
public class CommonController {

    @Autowired
    AddressService addressService;

    @Autowired
    ContactService contactService;

    @Autowired
    WhoChangedThingsService whoChangedThingsService;

    @PostMapping("/address")
    public ResponseEntity<?> saveAddress(@RequestBody AddressSaveViewModel viewModel) {
        log.info("Saving Address Registration: " + viewModel);
        var newId = addressService.save(viewModel, whoChangedThingsService.getWho());
        return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
    }

    @GetMapping("/address")
    public ResponseEntity<?> getAllAddresss() {
        return new ResponseEntity<>(addressService.getAll(), HttpStatus.OK);
    }

    @GetMapping("/address/{userid}")
    public ResponseEntity<?> getAddress(@PathVariable Long userid) {
        var viewModelList = addressService.getByUserId(userid);
        if (viewModelList == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return new ResponseEntity<>(viewModelList, HttpStatus.OK);
    }

    @PutMapping("/address/{id}")
    public ResponseEntity<?> updateAddress(@PathVariable Long id, @RequestBody AddressViewModel viewModel) {
        viewModel.setId(id);
        log.info("Updating Address Registration: " + viewModel);
        if (!addressService.update(viewModel, whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @DeleteMapping("/address/{id}")
    public ResponseEntity<?> deleteAddress(@PathVariable Long id) {
        log.info("Deleting Address Registration ID: " + id);
        if (!addressService.delete(id, whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @PostMapping("/contact")
    public ResponseEntity<?> saveContact(@RequestBody ContactSaveViewModel viewModel) {
        log.info("Saving Contact Registration: " + viewModel);
        var newId = contactService.save(viewModel, whoChangedThingsService.getWho());
        return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
    }

    @GetMapping("/contact")
    public ResponseEntity<?> getAllContacts() {
        return new ResponseEntity<>(contactService.getAll(), HttpStatus.OK);
    }

    @GetMapping("/contact/{userid}")
    public ResponseEntity<?> getContact(@PathVariable Long userid) {
        var viewModel = contactService.getAllByUserId(userid);
        if (viewModel == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return new ResponseEntity<>(viewModel, HttpStatus.OK);
    }

    @PutMapping("/contact/{id}")
    public ResponseEntity<?> updateContact(@PathVariable Long id, @RequestBody ContactViewModel viewModel) {
        viewModel.setId(id);
        log.info("Updating Contact Registration: " + viewModel);
        if (!contactService.update(viewModel, whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @DeleteMapping("/contact/{id}")
    public ResponseEntity<?> deleteContact(@PathVariable Long id) {
        log.info("Deleting Contact Registration ID: " + id);
        if (!contactService.delete(id, whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
