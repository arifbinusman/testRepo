package com.qvantage.recf.api.campaign.controllers;

import com.qvantage.recf.api.campaign.services.CampaignService;
import com.qvantage.recf.api.campaign.services.OriginatorCompanyInfoService;
import com.qvantage.recf.api.campaign.services.OriginatorCompanyOfficerService;
import com.qvantage.recf.api.campaign.services.PropertyService;
import com.qvantage.recf.api.campaign.viewmodels.*;
import com.qvantage.recf.api.common.services.WhoChangedThingsService;
import com.qvantage.recf.api.common.viewmodels.JustIdViewModel;
import com.qvantage.recf.api.file.services.FileService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Log4j2
@RestController
@RequestMapping("/api/v1")
public class CampaignController {

    @Autowired
    CampaignService campaignService;

    @Autowired
    OriginatorCompanyInfoService originatorCompanyInfoService;

    @Autowired
    OriginatorCompanyOfficerService originatorCompanyOfficerService;

    @Autowired
    PropertyService propertyService;

    @Autowired
    WhoChangedThingsService whoChangedThingsService;
    @Autowired
    FileService fileService;

    @PostMapping("/campaign")
    public ResponseEntity<?> saveCampaign(@RequestBody CampaignSaveViewModel viewModel) {
        log.info("Saving Campaign Registration: " + viewModel);
        var newId = campaignService.save(viewModel, whoChangedThingsService.getWho());
        return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
    }

    @GetMapping("/campaign")
    public ResponseEntity<?> getAllCampaigns() {
        return new ResponseEntity<>(campaignService.getAll(), HttpStatus.OK);
    }

    @GetMapping("/campaign/{id}")
    public ResponseEntity<?> getCampaign(@PathVariable Long id) {

        log.info("Get Campaign Registration: " + id);
        var viewModel = campaignService.get(id);
        if (viewModel == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return new ResponseEntity<>(viewModel, HttpStatus.OK);
    }

    @GetMapping("campaign/list/{country}")
    public ResponseEntity<?> getCampaignsByCountry(@PathVariable String country) {
        log.info("getting campaign by country");
        var viewModel = campaignService.getCampaignsByCountry(country);
        for (CampaignListViewModel vm:viewModel)
        {
            vm.setThumbnailImageUrls(fileService.getFileURLs(vm.getFileids()));
        }
        if (viewModel == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return new ResponseEntity<>(viewModel, HttpStatus.OK);
    }

    @PutMapping("/campaign/{id}")
    public ResponseEntity<?> updateCampaign(@PathVariable Long id, @RequestBody CampaignViewModel viewModel) {
        viewModel.setId(id);
        log.info("Updating Campaign Registration: " + viewModel);
        if (!campaignService.update(viewModel, whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @DeleteMapping("/campaign/{id}")
    public ResponseEntity<?> deleteCampaign(@PathVariable Long id) {
        log.info("Deleting Campaign Registration ID: " + id);
        if (!campaignService.delete(id, whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }


//    @PostMapping("/originator/companyinfo")
//    public ResponseEntity<?> saveOriginatorCompanyInfo(@RequestBody OriginatorCompanyInfoSaveViewModel viewModel) {
//        log.info("Saving OriginatorCompanyInfo : " + viewModel);
//        var newId = originatorCompanyInfoService.save(viewModel, whoChangedThingsService.getWho());
//        return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
//    }
//
//    @GetMapping("/originator/companyinfo")
//    public ResponseEntity<?> getAllOriginatorCompanies() {
//        return new ResponseEntity<>(originatorCompanyInfoService.getAll(), HttpStatus.OK);
//    }
//
//    @GetMapping("/originator/companyinfo/{userid}")
//    public ResponseEntity<?> getAllOriginatorCompaniesByUserId(@PathVariable Long userid) {
//        return new ResponseEntity<>(originatorCompanyInfoService.getByUserId(userid), HttpStatus.OK);
//    }
//
//    @PutMapping("/originator/companyinfo/{id}")
//    public ResponseEntity<?> updateOriginatorComanyInfo(@PathVariable Long id, @RequestBody OriginatorCompanyInfoViewModel viewModel) {
//        viewModel.setId(id);
//        log.info("Updating companyinfo : " + viewModel);
//        if (!originatorCompanyInfoService.update(viewModel, whoChangedThingsService.getWho())) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//        }
//        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
//    }
//
//    @DeleteMapping("/originator/companyinfo/{id}")
//    public ResponseEntity<?> deleteOriginatorCompanyInfo(@PathVariable Long id) {
//        log.info("Deleting companyinfo : " + id);
//        if (!originatorCompanyInfoService.delete(id, whoChangedThingsService.getWho())) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//        }
//        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
//    }
//
//
//    @PostMapping("/originator/companyofficer")
//    public ResponseEntity<?> saveOriginatorCompanyOfficer(@RequestBody OriginatorCompanyOfficerSaveViewModel viewModel) {
//        log.info("Saving OriginatorCompanyOfficer Registration: " + viewModel);
//        var newId = originatorCompanyOfficerService.save(viewModel, whoChangedThingsService.getWho());
//        return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
//    }
//
//    @GetMapping("/originator/companyofficer")
//    public ResponseEntity<?> getAllOriginatorCompanyOfficers() {
//        return new ResponseEntity<>(originatorCompanyOfficerService.getAll(), HttpStatus.OK);
//    }
//
//    @GetMapping("/originator/companyofficer/{companyid}")
//    public ResponseEntity<?> getOriginatorCompanyOfficer(@PathVariable Long companyid) {
//        log.info("Get companyofficers : " + companyid);
//        var viewModel = originatorCompanyOfficerService.getByCompanyId(companyid);
//        if (viewModel == null) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//        }
//        return new ResponseEntity<>(viewModel, HttpStatus.OK);
//    }
//
//    @PutMapping("/originator/companyofficer/{id}")
//    public ResponseEntity<?> updateOriginatorCompanyOfficer(@PathVariable Long id, @RequestBody OriginatorCompanyOfficerViewModel viewModel) {
//        viewModel.setId(id);
//        log.info("Updating OriginatorCompanyOfficer Registration: " + viewModel);
//        if (!originatorCompanyOfficerService.update(viewModel, whoChangedThingsService.getWho())) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//        }
//        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
//    }
//
//    @DeleteMapping("/originator/companyofficer/{id}")
//    public ResponseEntity<?> deleteOriginatorCompanyOfficer(@PathVariable Long id) {
//        log.info("Deleting OriginatorCompanyOfficer Registration ID: " + id);
//        if (!originatorCompanyOfficerService.delete(id, whoChangedThingsService.getWho())) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//        }
//        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
//    }

    @PostMapping("/property")
    public ResponseEntity<?> saveProperty(@RequestBody PropertySaveViewModel viewModel) {
        log.info("Saving Property Registration: " + viewModel);
        var newId = propertyService.save(viewModel, whoChangedThingsService.getWho());
        return new ResponseEntity<>(new JustIdViewModel(newId), HttpStatus.CREATED);
    }

    @GetMapping("/property")
    public ResponseEntity<?> getAllPropertys() {
        return new ResponseEntity<>(propertyService.getAll(), HttpStatus.OK);
    }

    @GetMapping("/property/{id}")
    public ResponseEntity<?> getProperty(@PathVariable Long id) {
        log.info("Get properties : " + id);
        var viewModel = propertyService.get(id);
        if (viewModel == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return new ResponseEntity<>(viewModel, HttpStatus.OK);
    }

    @PutMapping("/property/{id}")
    public ResponseEntity<?> updateProperty(@PathVariable Long id, @RequestBody PropertyViewModel viewModel) {
        viewModel.setId(id);
        log.info("Updating Property Registration: " + viewModel);
        if (!propertyService.update(viewModel, whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @DeleteMapping("/property/{id}")
    public ResponseEntity<?> deleteProperty(@PathVariable Long id) {
        log.info("Deleting Property Registration ID: " + id);
        if (!propertyService.delete(id, whoChangedThingsService.getWho())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
