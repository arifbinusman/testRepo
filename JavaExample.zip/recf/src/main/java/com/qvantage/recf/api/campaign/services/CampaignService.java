package com.qvantage.recf.api.campaign.services;

import com.qvantage.recf.api.campaign.models.CampaignModel;
import com.qvantage.recf.api.campaign.repositories.CampaignDal;
import com.qvantage.recf.api.campaign.repositories.CampaignRepository;
import com.qvantage.recf.api.campaign.viewmodels.CampaignListViewModel;
import com.qvantage.recf.api.campaign.viewmodels.CampaignSaveViewModel;
import com.qvantage.recf.api.campaign.viewmodels.CampaignViewModel;
import com.qvantage.recf.api.common.CommonMapper;

import java.util.ArrayList;
import java.util.List;

import com.qvantage.recf.api.file.services.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CampaignService {

    @Autowired
    private CampaignRepository repository;

    @Autowired
    private CommonMapper commonMapper;

    @Autowired
    CampaignDal campaignDal;

    @Autowired
    FileService fileService;

    public Long save(CampaignSaveViewModel viewModel, Long whoChangedThis) {
        var model = commonMapper.transmogrify(new CampaignModel(), viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return model.getId();
    }

    public List<CampaignViewModel> getAll() {
        var viewModelList = new ArrayList<CampaignViewModel>();
        for (var model : repository.findAllByIsDeleted(false)) {
            var viewModel = commonMapper.transmogrify(new CampaignViewModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }

    public List<CampaignListViewModel> getCampaignsByCountry(String country) {
        var viewModel= campaignDal.getCampaigns(country);
        return viewModel;
    }

    private CampaignModel getById(Long id) {
        var model = repository.findByIdAndIsDeleted(id, false);
        return model;
    }

    public CampaignViewModel get(Long id) {
        var model = getById(id);
        if (model == null) {
            return null;
        }
        var viewModel = commonMapper.transmogrify(new CampaignViewModel(), model);
        return viewModel;
    }

    public boolean update(CampaignViewModel viewModel, Long whoChangedThis) {
        var model = getById(viewModel.getId());
        if (model == null) {
            return false;
        }
        commonMapper.transmogrify(model, viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return true;
    }

    public boolean delete(Long id, Long whoChangedThis) {
        var model = getById(id);
        if (model == null) {
            return false;
        }
        model.setBeingChangedBy(whoChangedThis);
        model.setDeleted(true);
        repository.save(model);
        return true;
    }
}
