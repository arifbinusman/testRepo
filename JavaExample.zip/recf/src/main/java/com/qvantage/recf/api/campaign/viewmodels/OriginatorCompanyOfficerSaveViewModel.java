package com.qvantage.recf.api.campaign.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
public class OriginatorCompanyOfficerSaveViewModel {
    private Long companyId;
    private String offName;
    private String offType;
    private String offAdditionalInfo;

}
