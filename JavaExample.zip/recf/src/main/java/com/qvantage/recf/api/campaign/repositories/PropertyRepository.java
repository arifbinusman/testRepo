package com.qvantage.recf.api.campaign.repositories;

import com.qvantage.recf.api.campaign.models.PropertyModel;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PropertyRepository extends CrudRepository<PropertyModel, Long> {

    Iterable<PropertyModel> findAllByIsDeleted(boolean isDeleted);

    PropertyModel findByIdAndIsDeleted(Long id, boolean isDeleted);


}
