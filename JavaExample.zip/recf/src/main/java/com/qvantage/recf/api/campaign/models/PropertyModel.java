package com.qvantage.recf.api.campaign.models;

import com.qvantage.recf.api.common.BaseModel;
import com.vladmihalcea.hibernate.type.array.LongArrayType;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import java.math.BigDecimal;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "properties")
@ToString(callSuper = true)
@TypeDefs({
        @TypeDef(
                name = "long-array",
                typeClass = LongArrayType.class
        )
})
public class PropertyModel extends BaseModel {

    @Column(name = "propertytype")
    private Short propertyType;

    @Column(name = "address")
    private String address;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "zipcode")
    private String zipCode;

    @Column(name = "country")
    private String country;

    @Column(name = "investmentperiod")
    private Short investmentPeriod;

    @Column(name = "initialgrosspropertyyieldpa")
    private BigDecimal initialGrossPropertyYieldpa;

    @Column(name = "annualisedcashyield")
    private BigDecimal annualisedCashYield;

    @Column(name = "annualisedreturn")
    private BigDecimal annualisedReturn;

    @Type( type = "long-array" )
    @Column(
            name = "thumbnailfileids",
            columnDefinition = "Long[]"
    )
    private Long[] thumbnailFileids;

    @Column(name = "assetprice")
    private BigDecimal assetPrice;

    @Column(name = "currency")
    private String currency;
}
