package com.qvantage.recf.api.usermgt.models;

import com.qvantage.recf.api.common.BaseModel;

import java.time.LocalDate;
import java.util.Set;
import javax.persistence.*;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "users")
@ToString(callSuper = true)
public class UserModel extends BaseModel {

    @Column(name = "usertype")
    private Short userType;

    @Column(name = "username")
    private String userName;

    @Column(name = "useremail")
    private String userEmail;

    @Column(name = "password")
    private String password;

    @Column(name = "fullname")
    private String fullName;

    @Column(name = "isagreetoterms")
    private Boolean isAgreeToTerms;

    @Column(name = "isemailverified")
    private Boolean isEmailVerified;

    @Column(name = "istwofaregistered")
    private Short isTwoFARegistered;

    @Column(name = "isaccountlocked")
    private Boolean isAccountLocked;

    @Column(name = "failedloginattempts")
    private Short failedLoginAttempts;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "userroles",
            joinColumns =  @JoinColumn(name ="userid"),inverseJoinColumns= @JoinColumn(name="roleid"))
    private Set<RolesModel> roles;

    public Set<RolesModel> getRoles() {
        return roles;
    }

    public void setRoles(Set<RolesModel> roles) {
        this.roles = roles;
    }

}
