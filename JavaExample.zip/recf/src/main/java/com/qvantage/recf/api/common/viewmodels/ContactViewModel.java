package com.qvantage.recf.api.common.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
public class ContactViewModel {
    private Long id;
    private Long userId;
    private String contactDetailType;
    private String contactDetail;
    private Short isPreferredMethod;
    private Long updatedBy;
    private Instant updatedAt;
}
