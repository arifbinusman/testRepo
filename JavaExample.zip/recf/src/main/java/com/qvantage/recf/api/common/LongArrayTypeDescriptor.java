package com.qvantage.recf.api.common;

public class LongArrayTypeDescriptor
        extends AbstractArrayTypeDescriptor<Long[]> {

    public static final LongArrayTypeDescriptor INSTANCE =
            new LongArrayTypeDescriptor();

    public LongArrayTypeDescriptor() {
        super( Long[].class );
    }

    @Override
    protected String getSqlArrayType() {
        return "integer";
    }
}