//package com.qvantage.recf.api.transactions.models;
//
//import java.math.BigDecimal;
//import java.time.Instant;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//import lombok.EqualsAndHashCode;
//import lombok.Getter;
//import lombok.Setter;
//import lombok.ToString;
//import org.hibernate.annotations.CreationTimestamp;
//
//@Entity
//@EqualsAndHashCode
//@Getter
//@Setter
//@Table(name = "transactions")
//@ToString
//public class UserTransactionModel {
//
//    @Column(name = "id")
//    @EqualsAndHashCode.Exclude
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Id
//    private Long id;
//
//    @Column(name = "userid")
//    private Long userId;
//
//    @Column(name = "currencycode")
//    private String currencyCode;
//
//    @Column(name = "creditamount")
//    private BigDecimal creditAmount;
//
//    @Column(name = "previousledgerbalance")
//    private BigDecimal previousLedgerBalance;
//
//    @Column(name = "transactionreference")
//    private String transactionReference;
//
//    @Column(name = "narrationcode")
//    private String narrationCode;
//
//    @Column(name = "createdby")
//    private Long createdBy;
//
//    @Column(name = "createdat")
//    @CreationTimestamp
//    private Instant createdAt;
//}
