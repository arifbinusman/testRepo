package com.qvantage.recf.api.campaign.models;

import com.qvantage.recf.api.common.BaseModel;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "originatorcompanyinfo")
@ToString(callSuper = true)
public class OriginatorCompanyInfoModel extends BaseModel {

    @Column(name = "userid")
    private Long userId;

    @Column(name = "companyname")
    private String companyName;

    @Column(name = "companyregnnumber")
    private String companyRegnNumber;
}
