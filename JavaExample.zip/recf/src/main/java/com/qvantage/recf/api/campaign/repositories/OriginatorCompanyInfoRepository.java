package com.qvantage.recf.api.campaign.repositories;

import com.qvantage.recf.api.campaign.models.OriginatorCompanyInfoModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;

@Repository
public interface OriginatorCompanyInfoRepository extends CrudRepository<OriginatorCompanyInfoModel, Long> {

    Iterable<OriginatorCompanyInfoModel> findAllByIsDeleted(boolean isDeleted);

    Iterable<OriginatorCompanyInfoModel> findAllByUserId(Long userId);

    OriginatorCompanyInfoModel findByIdAndIsDeleted(Long id, boolean isDeleted);

    OriginatorCompanyInfoModel findByIdAndUpdatedAt(Long id, Instant updatedAt);
}
