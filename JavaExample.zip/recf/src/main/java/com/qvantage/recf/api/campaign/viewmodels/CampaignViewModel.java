package com.qvantage.recf.api.campaign.viewmodels;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CampaignViewModel {

    private Long id;
    private Long propertyId;
    private String title;
    private String detailedDescription;
    private LocalDate launchDate;
    private LocalTime launchTime;
    private String additionalInfo;
    private BigDecimal expectedAmount;
    private BigDecimal finalAmount;
    private BigDecimal minInvestmentAmount;
    private BigDecimal investmentMultiple;
    private Short status;
    private Short validityInDays;
    private Long updatedBy;
    private Instant updatedAt;
}
