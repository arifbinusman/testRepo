package com.qvantage.recf.api.usermgt.models;

import com.qvantage.recf.api.common.BaseModel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Table(name = "roles")
@ToString(callSuper = true)
public class RolesModel extends BaseModel {

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;
}
