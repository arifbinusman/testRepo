package com.qvantage.recf.api.fundtransfer.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
public class FundTransferRequestViewModel {

    private long userId;
    private BigDecimal amount;
    private String comment;
    private String currency;
    private Long[] fileids;

}
