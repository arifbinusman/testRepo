package com.qvantage.recf.api.campaign.rowmappers;


import com.qvantage.recf.api.campaign.viewmodels.CampaignListViewModel;
import com.qvantage.recf.api.file.services.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;



public class CampaignListRowMapper implements RowMapper<CampaignListViewModel> {


    @Override
    public CampaignListViewModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        CampaignListViewModel propertyModel = new CampaignListViewModel();
        propertyModel.setPropertyid(rs.getLong("propertyid"));
        propertyModel.setCampaignid(rs.getLong("campaignid"));
        propertyModel.setPropertyType(rs.getShort("propertytype"));
        propertyModel.setAddress(rs.getString("address"));
        propertyModel.setCity(rs.getString("city"));
        propertyModel.setState(rs.getString("state"));
        propertyModel.setCountry(rs.getString("country"));
        propertyModel.setZipCode(rs.getString("zipcode"));
        propertyModel.setInvestmentPeriod(rs.getShort("investmentperiod"));
        propertyModel.setInitialGrossPropertyYieldpa(rs.getBigDecimal("initialgrosspropertyyieldpa"));
        propertyModel.setAnnualisedCashYield(rs.getBigDecimal("annualisedcashyield"));
        propertyModel.setAnnualisedReturn(rs.getBigDecimal("annualisedreturn"));
        Array arr = rs.getArray("thumbnailfileids");
        propertyModel.setFileids((Long[]) arr.getArray());
        propertyModel.setExpectedAmount(rs.getBigDecimal("expectedamount"));
        propertyModel.setFundedAmount(rs.getBigDecimal("fundedAmount"));
        propertyModel.setMiniumInvestmentAmount(rs.getBigDecimal("mininvestmentamount"));
        propertyModel.setAssetPrice(rs.getBigDecimal("assetprice"));
        propertyModel.setCurrency(rs.getString("currency"));


        return propertyModel;

    }
}
