package com.qvantage.recf.api.file.repositories;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.util.IOUtils;
import com.qvantage.recf.api.file.models.FileModel;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.List;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Log4j2
public class AWSFileRepository {

    @Autowired
    private AmazonS3 amazonS3;

    @Value("${cloud.aws.s3.bucket}")
    private String bucket;

    public PutObjectResult upload(InputStream inputStream, String uploadKey) {
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucket, uploadKey, inputStream, new ObjectMetadata());
        putObjectRequest.setCannedAcl(CannedAccessControlList.Private);
        PutObjectResult putObjectResult = amazonS3.putObject(putObjectRequest);
        // IOUtils.closeQuietly(inputStream);
        return putObjectResult;
    }


    public byte[] download(String key) throws IOException {
        GetObjectRequest getObjectRequest = new GetObjectRequest(bucket, key);
        S3Object s3Object = amazonS3.getObject(getObjectRequest);
        S3ObjectInputStream objectInputStream = s3Object.getObjectContent();
        byte[] bytes = IOUtils.toByteArray(objectInputStream);
        return bytes;
    }

    public void deleteFile(String key) {
        DeleteObjectRequest geleteObjectRequest = new DeleteObjectRequest(bucket, key);
        amazonS3.deleteObject(geleteObjectRequest);
    }

    public String createAbsolutePath(FileModel fileModel) {
        return fileModel.getFileDocType() + '/' + fileModel.getFileName();
    }
    public String generatePresignedFileUrl(String key)
    {

        java.util.Date expiration = new java.util.Date();
        long expTimeMillis = expiration.getTime();
        expTimeMillis += 1000 * 60 * 60;
        expiration.setTime(expTimeMillis);

        GeneratePresignedUrlRequest generatePresignedUrlRequest =
                new GeneratePresignedUrlRequest(bucket, key)
                        .withMethod(HttpMethod.GET)
                        .withExpiration(expiration);
        return amazonS3.generatePresignedUrl(generatePresignedUrlRequest).toString();
    }
}
