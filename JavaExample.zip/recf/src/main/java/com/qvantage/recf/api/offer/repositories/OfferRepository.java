package com.qvantage.recf.api.offer.repositories;

import com.qvantage.recf.api.offer.models.OfferModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OfferRepository extends PagingAndSortingRepository<OfferModel,Long> {
    OfferModel findByIdAndIsDeleted(Long id, boolean isDeleted);
    Iterable<OfferModel> findAllByUserIdAndAndIsDeleted(Long userId,boolean isDeleted);
    Iterable<OfferModel> findAllByCampaignIdAndIsDeleted(Long campaignId,boolean isDeleted);
}
