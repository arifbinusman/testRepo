package com.qvantage.recf.api.usermgt.services;

import com.qvantage.recf.api.common.CommonMapper;
import com.qvantage.recf.api.usermgt.models.AmlDetailModel;
import com.qvantage.recf.api.usermgt.repositories.AmlDetailRepository;
import com.qvantage.recf.api.usermgt.viewmodels.AmlDetailViewModel;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import com.qvantage.recf.api.usermgt.viewmodels.AmlSaveViewModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AmlDetailService {

    @Autowired
    private AmlDetailRepository repository;

    @Autowired
    private CommonMapper commonMapper;

    public Long save(AmlSaveViewModel viewModel, Long whoChangedThis) {
        var model = commonMapper.transmogrify(new AmlDetailModel(), viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return model.getId();
    }

    public List<AmlDetailViewModel> getAll() {
        var viewModelList = new ArrayList<AmlDetailViewModel>();
        for (var model : repository.findAllByIsDeleted(false)) {
            var viewModel = commonMapper.transmogrify(new AmlDetailViewModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }
    public List<AmlDetailViewModel> getByUserId(Long userId) {
        var viewModelList = new ArrayList<AmlDetailViewModel>();
        for (var model : repository.findAllByUserId(userId)) {
            var viewModel = commonMapper.transmogrify(new AmlDetailViewModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }
    private AmlDetailModel getById(Long id) {
        var model = repository.findByIdAndIsDeleted(id, false);
        return model;
    }
    private AmlDetailModel getByIdAndupdatedAt(Long id, Instant updatedAT) {
        var model = repository.findByIdAndUpdatedAt(id, updatedAT);
        return model;
    }

    public AmlDetailViewModel get(Long id) {
        var model = getById(id);
        if (model == null) {
            return null;
        }
        var viewModel = commonMapper.transmogrify(new AmlDetailViewModel(), model);
        return viewModel;
    }

    public boolean update(AmlDetailViewModel viewModel, Long whoChangedThis) {
        var model = getByIdAndupdatedAt(viewModel.getId(),viewModel.getUpdatedAt());
        if (model == null) {
            return false;
        }
        commonMapper.transmogrify(model, viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return true;
    }

    public boolean delete(Long id, Long whoChangedThis) {
        var model = getById(id);
        if (model == null) {
            return false;
        }
        model.setBeingChangedBy(whoChangedThis);
        model.setDeleted(true);
        repository.save(model);
        return true;
    }
}
