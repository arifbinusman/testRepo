package com.qvantage.recf.api.common;

import com.vladmihalcea.hibernate.type.array.internal.ArraySqlTypeDescriptor;
import org.hibernate.type.AbstractSingleColumnStandardBasicType;
import org.hibernate.usertype.DynamicParameterizedType;
import java.util.Properties;

public class BigIntArrayType extends AbstractSingleColumnStandardBasicType<Long[]>
        implements DynamicParameterizedType {
    public BigIntArrayType() {
        super(
                ArraySqlTypeDescriptor.INSTANCE,
                LongArrayTypeDescriptor.INSTANCE
        );
    }

    public String getName() {
        return "long-array";
    }

    @Override
    protected boolean registerUnderJavaType() {
        return true;
    }

    @Override
    public void setParameterValues(Properties parameters) {
        ((AbstractArrayTypeDescriptor)
                getJavaTypeDescriptor())
                .setParameterValues(parameters);
    }
}
//https://stackoverflow.com/questions/1647583/mapping-a-postgresql-array-with-hibernate