package com.qvantage.recf.api.fundtransfer.controllers;

import com.qvantage.recf.api.common.APIErrorMessage;
import com.qvantage.recf.api.common.services.WhoChangedThingsService;
import com.qvantage.recf.api.fundtransfer.services.FundTransferService;
import com.qvantage.recf.api.fundtransfer.viewmodels.FundTransferRequestViewModel;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Log4j2
@RestController
@RequestMapping("/api/v1")
public class FundManagementController {

    @Autowired
    FundTransferService fundTransferService;

    @Autowired
    WhoChangedThingsService whoChangedThingsService;

    @PostMapping("/funds/fundtransferinrequest")
    public ResponseEntity<?> saveFundTransferInRequest(@RequestBody FundTransferRequestViewModel viewModel) {
        log.info("Saving fundtransfer in request" + viewModel);
        fundTransferService.saveFundTransferInRequest(viewModel, whoChangedThingsService.getWho());
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("funds/approveftirequest/{id}")
    public ResponseEntity<?> approveftiRequest(@RequestParam Long id) {
        log.info("approving FTI request");
        fundTransferService.aproveFundTransferInRequest(id, whoChangedThingsService.getWho());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("funds/rejectftirequest/{id}")
    public ResponseEntity<?> rejectftiRequest(@RequestParam Long id) {
        log.info("approving FTI request");
        fundTransferService.rejectFundTransferInRequest(id, whoChangedThingsService.getWho());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/funds/fundtransferoutrequest")
    public ResponseEntity<?> saveFundTransferOutRequest(@RequestBody FundTransferRequestViewModel viewModel) {
        log.info("Saving fundtransfer in request" + viewModel);
        if (fundTransferService.saveFundTransferOutRequest(viewModel, whoChangedThingsService.getWho()) > 0) {
            return new ResponseEntity<>(HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(new APIErrorMessage("cannot withdraw more than available balance in wallet"), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("funds/approveftorequest/{id}")
    public ResponseEntity<?> approveftoRequest(@RequestParam Long id) {
        log.info("approving FTI request");
        fundTransferService.aproveFundTransferOutRequest(id, whoChangedThingsService.getWho());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("funds/rejectftorequest/{id}")
    public ResponseEntity<?> rejectftoRequest(@RequestParam Long id) {
        log.info("approving FTI request");
        fundTransferService.rejectFundTransferOutRequest(id, whoChangedThingsService.getWho());
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
