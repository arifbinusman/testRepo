package com.qvantage.recf.api.common.repositories;

import com.qvantage.recf.api.common.models.AddressModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;

@Repository
public interface AddressRepository extends CrudRepository<AddressModel, Long> {

    Iterable<AddressModel> findAllByIsDeleted(boolean isDeleted);

    Iterable<AddressModel> findAllByUserId(Long userId);

    AddressModel findByIdAndIsDeleted(Long id, boolean isDeleted);
    AddressModel findByIdAndUpdatedAt(Long id, Instant updatedAt);
}
