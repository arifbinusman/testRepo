package com.qvantage.recf.api.file.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Configurable
public class FileService {

    @Autowired
    FileDBService fileDBService;

    @Autowired
    FileAwsService fileAwsService;

    public List<String> getFileURLs(Long[] fileids) {
        var fileModels = fileDBService.getByFileIdIn(fileids);
        var retList = new ArrayList<String>();
        for (var file : fileModels) {
            retList.add(fileAwsService.generatePreSignedFileUrl(file.getFileFullPath()));
        }
        return retList;
    }
}
