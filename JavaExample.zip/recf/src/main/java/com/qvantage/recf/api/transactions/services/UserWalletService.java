package com.qvantage.recf.api.transactions.services;

import com.qvantage.recf.api.common.CommonMapper;
import com.qvantage.recf.api.transactions.models.UserWalletModel;
import com.qvantage.recf.api.transactions.repositories.UserWalletRepository;
import com.qvantage.recf.api.transactions.viewmodels.UserWalletViewModel;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserWalletService {

    @Autowired
    private UserWalletRepository repository;

    @Autowired
    private CommonMapper commonMapper;

    public List<UserWalletViewModel> getAllByUserId(Long userId) {
        var viewModelList = new ArrayList<UserWalletViewModel>();
        for (var model : repository.findAllByUserId(userId)) {
            var viewModel = commonMapper.transmogrify(new UserWalletViewModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }
    public UserWalletModel findByuserIdAndCurrencyCode(Long userId,String currencyCode)
    {
        return repository.findByUserIdAndCurrencyCode(userId,currencyCode);
    }
}
