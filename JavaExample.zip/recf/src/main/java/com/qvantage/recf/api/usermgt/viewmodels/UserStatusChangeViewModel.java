package com.qvantage.recf.api.usermgt.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserStatusChangeViewModel {
    private Long userId;
    private Short kycStatus;
    private Short amlStatus;
    private Short userStatus;
}
