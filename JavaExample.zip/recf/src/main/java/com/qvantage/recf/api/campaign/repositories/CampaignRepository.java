package com.qvantage.recf.api.campaign.repositories;

import com.qvantage.recf.api.campaign.models.CampaignModel;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CampaignRepository extends PagingAndSortingRepository<CampaignModel, Long> {

    Iterable<CampaignModel> findAllByIsDeleted(boolean isDeleted);

    CampaignModel findByIdAndIsDeleted(Long id, boolean isDeleted);

}
//https://dzone.com/articles/spring-data-part-5-paging-and-sorting