package com.qvantage.recf.api.common;

import lombok.Data;
import org.springframework.http.HttpStatus;
@Data
public class APIErrorMessage {

    private String message;


    public APIErrorMessage(String message) {
        this.message = message;
    }
}
