package com.qvantage.recf.api.file.controllers;

import com.qvantage.recf.api.common.services.WhoChangedThingsService;
import com.qvantage.recf.api.file.models.FileModel;
import com.qvantage.recf.api.file.services.FileAwsService;
import com.qvantage.recf.api.file.services.FileDBService;

import java.io.IOException;
import java.util.UUID;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@Log4j2
@RestController
@RequestMapping("/api/v1")
public class FileController {

    @Autowired
    FileDBService fileDBService;
    @Autowired
    WhoChangedThingsService whoChangedThingsService;
    @Autowired
    FileAwsService fileAwsService;

    @GetMapping("/file/{id}")
    public ResponseEntity<ByteArrayResource> downloadFile(Long id) throws IOException {
        FileModel fileModel = fileDBService.getFileById(id);
        if (fileModel != null) {
            fileAwsService.downloadFile(fileModel);
            byte[] data = fileModel.getFileContent();
            ByteArrayResource resource = new ByteArrayResource(data);
            String contentType = "application/octet-stream";
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fileModel.getActualFileName())
                    .contentType(MediaType.parseMediaType(contentType))
                    .contentLength(data.length) //
                    .body(resource);

        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @PostMapping("/file/publicimage")
    public ResponseEntity<String> savePublicImage(@RequestParam("file") MultipartFile file) throws IOException {
        FileModel fileModel = saveFileToService(file, "publicimage");
        return new ResponseEntity<>(fileModel.getId().toString(), HttpStatus.CREATED);
    }
    @PostMapping("/file/profile")
    public ResponseEntity<String> saveProfilesDoc(@RequestParam("file") MultipartFile file) throws IOException {
        FileModel fileModel = saveFileToService(file, "profiles");
        return new ResponseEntity<>(fileModel.getId().toString(), HttpStatus.CREATED);
    }

    @PostMapping("/file/campaign")
    public ResponseEntity<String> saveCampaignsDoc(@RequestParam("file") MultipartFile file) throws IOException {
        FileModel fileModel = saveFileToService(file, "campaigns");
        return new ResponseEntity<>(fileModel.getId().toString(), HttpStatus.CREATED);
    }

    @PostMapping("/file/contract")
    public ResponseEntity<String> saveContractsDoc(@RequestParam("file") MultipartFile file) throws IOException {
        FileModel fileModel = saveFileToService(file, "contracts");
        return new ResponseEntity<>(fileModel.getId().toString(), HttpStatus.CREATED);

    }

    private FileModel saveFileToService(@RequestParam("file") MultipartFile file, String documentType) throws IOException {
        FileModel fileModel = new FileModel();
        String fileName = UUID.randomUUID().toString() + '|' + file.getOriginalFilename();

        fileModel.setFileDocType(documentType);
        fileModel.setActualFileName(file.getOriginalFilename());
        fileModel.setFileName(fileName);

        fileModel.setFileExtension(file.getContentType());
        fileModel.setFileSize(file.getSize());
        fileAwsService.uploadFile(fileModel, file.getInputStream());
        fileDBService.saveFile(fileModel, whoChangedThingsService.getWho());
        return fileModel;
    }
}
