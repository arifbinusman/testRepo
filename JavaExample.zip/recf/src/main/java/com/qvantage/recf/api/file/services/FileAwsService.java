package com.qvantage.recf.api.file.services;

import com.amazonaws.services.s3.model.PutObjectResult;
import com.qvantage.recf.api.file.models.FileModel;
import com.qvantage.recf.api.file.repositories.AWSFileRepository;
import java.io.IOException;
import java.io.InputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;

@Service
@Configurable
public class FileAwsService {

    @Autowired
    AWSFileRepository awsFileRepository;

    public FileModel uploadFile(FileModel fileModel, InputStream inputStream) {
        String fileKey = awsFileRepository.createAbsolutePath(fileModel);
        PutObjectResult result = awsFileRepository.upload(inputStream, fileKey);
        fileModel.setFileChecksum(result.getContentMd5());
        fileModel.setFileFullPath(fileKey);
        return fileModel;
    }

    public FileModel downloadFile(FileModel fileModel) throws IOException {
        fileModel.setFileContent(awsFileRepository.download(fileModel.getFileFullPath()));
        return fileModel;
    }

    public  String generatePreSignedFileUrl(String fileKey)
    {
        return awsFileRepository.generatePresignedFileUrl(fileKey);
    }
}
