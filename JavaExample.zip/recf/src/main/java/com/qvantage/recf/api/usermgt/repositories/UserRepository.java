package com.qvantage.recf.api.usermgt.repositories;

import com.qvantage.recf.api.usermgt.models.UserModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends CrudRepository<UserModel, Long> {

    Iterable<UserModel> findAllByIsDeleted(boolean isDeleted);

    UserModel findByIdAndIsDeleted(Long id, boolean isDeleted);

    UserModel findByUserEmail(String email);
}
