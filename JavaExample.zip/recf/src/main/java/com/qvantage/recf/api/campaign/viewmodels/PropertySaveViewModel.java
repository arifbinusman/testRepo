package com.qvantage.recf.api.campaign.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
public class PropertySaveViewModel {
    private Short propertyType;
    private String address;
    private String city;
    private String state;
    private String zipCode;
    private String country;
    private Short investmentPeriod;
    private BigDecimal initialGrossPropertyYieldpa;
    private BigDecimal annualisedCashYield;
    private BigDecimal annualisedReturn;
    private Long[] thumbnailFileids;
    private BigDecimal assetPrice;
    private String currency;
}
