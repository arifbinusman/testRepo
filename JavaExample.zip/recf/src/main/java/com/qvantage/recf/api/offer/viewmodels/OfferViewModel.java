package com.qvantage.recf.api.offer.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;

@Data
@NoArgsConstructor
public class OfferViewModel {
    private Long id;
    private Long campaignId;
    private Long userId;
    private BigDecimal offeredAmount;
    private BigDecimal acceptedAmount;
    private boolean isAgreeToTerms;
    private short status;
    private boolean isDeleted;
    private Long updatedBy;
    private Instant updatedAt;
}
