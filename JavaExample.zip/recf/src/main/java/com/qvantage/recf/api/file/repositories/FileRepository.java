package com.qvantage.recf.api.file.repositories;


import com.qvantage.recf.api.file.models.FileModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileRepository extends CrudRepository<FileModel, Long> {

    FileModel getFileById(Long fileId);

    List<FileModel> findAllByIdIn(Long[] ids);
}
