package com.qvantage.recf.api.usermgt.repositories;

import com.qvantage.recf.api.usermgt.models.AmlDetailModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;

@Repository
public interface AmlDetailRepository extends CrudRepository<AmlDetailModel, Long> {
    Iterable<AmlDetailModel> findAllByIsDeleted(boolean isDeleted);
    AmlDetailModel findByIdAndIsDeleted(Long id, boolean isDeleted);
    AmlDetailModel findByIdAndUpdatedAt(Long id, Instant updateAt);
    Iterable<AmlDetailModel> findAllByUserId(Long userId);
}
