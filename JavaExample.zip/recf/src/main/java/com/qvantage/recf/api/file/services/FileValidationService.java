package com.qvantage.recf.api.file.services;

import org.springframework.stereotype.Service;

@Service
public class FileValidationService {

}
