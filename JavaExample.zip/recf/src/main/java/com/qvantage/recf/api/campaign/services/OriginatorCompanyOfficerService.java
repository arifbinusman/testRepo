package com.qvantage.recf.api.campaign.services;

import com.qvantage.recf.api.campaign.models.OriginatorCompanyOfficerModel;
import com.qvantage.recf.api.campaign.repositories.OriginatorCompanyOfficerRepository;
import com.qvantage.recf.api.campaign.viewmodels.OriginatorCompanyOfficerSaveViewModel;
import com.qvantage.recf.api.campaign.viewmodels.OriginatorCompanyOfficerViewModel;
import com.qvantage.recf.api.common.CommonMapper;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OriginatorCompanyOfficerService {

    @Autowired
    private OriginatorCompanyOfficerRepository repository;

    @Autowired
    private CommonMapper commonMapper;

    public Long save(OriginatorCompanyOfficerSaveViewModel viewModel, Long whoChangedThis) {
        var model = commonMapper.transmogrify(new OriginatorCompanyOfficerModel(), viewModel);
        model.setId(null);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return model.getId();
    }

    public List<OriginatorCompanyOfficerViewModel> getAll() {
        var viewModelList = new ArrayList<OriginatorCompanyOfficerViewModel>();
        for (var model : repository.findAllByIsDeleted(false)) {
            var viewModel = commonMapper.transmogrify(new OriginatorCompanyOfficerViewModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }
    public List<OriginatorCompanyOfficerViewModel> getByCompanyId(Long companyId) {
        var viewModelList = new ArrayList<OriginatorCompanyOfficerViewModel>();
        for (var model : repository.findByCompanyIdAndIsDeleted(companyId,false)) {
            var viewModel = commonMapper.transmogrify(new OriginatorCompanyOfficerViewModel(), model);
            viewModelList.add(viewModel);
        }
        return viewModelList;
    }

    private OriginatorCompanyOfficerModel getById(Long id) {
        var model = repository.findByIdAndIsDeleted(id, false);
        return model;
    }
    private OriginatorCompanyOfficerModel getByIdAndUpdatedAt(Long id, Instant updatedAt) {
        var model = repository.findByIdAndUpdatedAt(id, updatedAt);
        return model;
    }
    public OriginatorCompanyOfficerViewModel get(Long id) {
        var model = getById(id);
        if (model == null) {
            return null;
        }
        var viewModel = commonMapper.transmogrify(new OriginatorCompanyOfficerViewModel(), model);
        return viewModel;
    }

    public boolean update(OriginatorCompanyOfficerViewModel viewModel, Long whoChangedThis) {
        var model = getByIdAndUpdatedAt(viewModel.getId(),viewModel.getUpdatedAt());
        if (model == null) {
            return false;
        }
        commonMapper.transmogrify(model, viewModel);
        model.setBeingChangedBy(whoChangedThis);
        repository.save(model);
        return true;
    }

    public boolean delete(Long id, Long whoChangedThis) {
        var model = getById(id);
        if (model == null) {
            return false;
        }
        model.setBeingChangedBy(whoChangedThis);
        model.setDeleted(true);
        repository.save(model);
        return true;
    }
}
