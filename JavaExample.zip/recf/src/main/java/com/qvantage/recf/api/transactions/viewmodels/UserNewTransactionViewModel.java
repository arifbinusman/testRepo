//package com.qvantage.recf.api.transactions.viewmodels;
//
//import java.math.BigDecimal;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//public class UserNewTransactionViewModel {
//
//    private Long userId;
//    private String currencyCode;
//    private BigDecimal creditAmount;
//    private BigDecimal debitAmount;
//    private String transactionReference;
//    private String narrationCode;
//}
