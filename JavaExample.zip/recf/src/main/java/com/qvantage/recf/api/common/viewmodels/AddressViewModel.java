package com.qvantage.recf.api.common.viewmodels;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
public class AddressViewModel {
   private  Long id;
    private Long userId;
    private Short addressType;
    private String address1;
    private String address2;
    private String zipCode;
    private String city;
    private String state;
    private String country;
    private Long[] fileids;
    private Boolean isActive;
    private Long updatedBy;
    private Instant updatedAt;
}
