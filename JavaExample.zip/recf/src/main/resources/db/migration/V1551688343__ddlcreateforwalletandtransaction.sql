drop table if exists userwallets;
drop table if exists usertransactions;
drop table if exists fundtransferrequest;

drop table if exists fundtransferrequest;
-- table: public.fundtransferrequest

-- drop table public.fundtransferrequest;


create table  fundtransferrequest
(
  id bigint generated always as identity,
  userid bigint,
  amount numeric,
  currencycode varchar(3),
  comment character varying(2000) collate pg_catalog."default",
  status smallint, --1 - submitted, 2 accepted, 3 rejected, 4 cancelled, 5 dispute
  direction smallint, --1 -- in, 2-- out
  fileids bigint[] null, -- list of file ids.
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamp with time zone,
  updatedby bigint,
  updatedat timestamp with time zone,
  constraint fundtransferrequestpk primary key (id)
)
  with (
    oids = false
  )
  tablespace pg_default;




-- table: public.fundtransferrequestaudit

drop table if exists fundtransferrequestaudit;

create table fundtransferrequestaudit
(
  requestauditid bigint generated always as identity,
  operation char(1), --i. inserted, u. updated (new values)
  requestid bigint,
  userid bigint,
  amount numeric,
  currencycode varchar(3),
  comment character varying(2000) collate pg_catalog."default",
  status smallint, --1 - submitted, 2 accepted, 3 rejected, 4 cancelled, 5 dispute
  direction smallint, --1 -- in, 2-- out
  fileids bigint[] null, -- list of file ids.
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamp with time zone,
  updatedby bigint,
  updatedat timestamp with time zone,
  constraint fundtransferrequestprimarykey primary key (requestauditid)
)
  with (
    oids = false
  )
  tablespace pg_default;


-- table: public.usertransactions

drop table  if exists transactions;

create table transactions
(
  id bigint generated always as identity,
  userid bigint not null,
  currencycode varchar(3),
  creditamount numeric not null,
  debitamount numeric not null,
  previousbalance numeric not null,
  newbalance numeric not null,
  transactiontype smallint not null,
  transactionsourceid bigint not null,
  createdby bigint not null,
  createdat timestamp with time zone not null,
  constraint transactionpk primary key (id)
)
  with (
    oids = false
  )
  tablespace pg_default;



-- index: usertransactions_userid_currencycode_createdat_idx

-- drop index public.usertransactions_userid_currencycode_createdat_idx;

create index transactionuidccd
  on public.transactions using btree
    (userid, currencycode collate pg_catalog."default", createdat)
  tablespace pg_default;



-- table: public.transactiontype

drop table if exists transactiontype;

create table transactiontype
(
  transactiontypeid smallint generated always as identity,
  value char(20),
  constraint transactiontypeprimarykey primary key (transactiontypeid)
)
  with (
    oids = false
  )
  tablespace pg_default;

------------------------------

-- table: public.wallet

drop table if exists wallet;

create table wallet
(
  id bigint generated always as identity,
  userid bigint,
  currencycode varchar(3),
  actualbalance numeric,
  ledgerbalance numeric,
  createdby bigint,
  createdat timestamp with time zone,
  updatedby bigint,
  updatedat timestamp with time zone,
  constraint walletpk primary key (id)
)
  with (
    oids = false
  )
  tablespace pg_default;

create unique index walletuniqueuidcc on wallet (userid, currencycode);



---------------------------------

-- table: public.walletaudit

drop table if exists walletaudit;

create table walletaudit
(
  walletauditid bigint generated always as identity,
  operation char(1), -- 'i' insert, 'u' update.
  walletid bigint not null,
  userid bigint not null,
  currencycode varchar(3),
  actualbalance numeric,
  ledgerbalance numeric,
  createdby bigint,
  createdat timestamp with time zone,
  updatedby bigint,
  updatedat timestamp with time zone,
  constraint walletauditprimarykey primary key (walletauditid)
)
  with (
    oids = false
  )
  tablespace pg_default;



create index idx_walletaudit on walletaudit (walletid);

---------------------------------------
-- table: public.transactiontypestatic

-- delete from public.transactiontype;

insert into transactiontype(value)
values ('fundtransferin');

insert into transactiontype(value)
values ('fundtransferout');

insert into transactiontype(value)
values ('offers');

insert into transactiontype(value)
values ('distribution');

-------------------------------------
