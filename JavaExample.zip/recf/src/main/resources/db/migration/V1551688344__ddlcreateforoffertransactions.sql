-- table: public.offers

drop table if exists offers;

create table offers
(
  id bigint generated always as identity,
  userid bigint,
  currencycode varchar(3),
  campaignid bigint,
  offeredamount numeric,
  acceptedamount numeric,
  status smallint,
  isagreetoterms boolean not null default false,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamp with time zone,
  updatedby bigint,
  updatedat timestamp with time zone,
  constraint offerspk primary key (id)
)
  with (
    oids = false
  )
  tablespace pg_default;
---------------------------------
drop table if exists offersaudit;
-- table: public.offersaudit

-- drop table public.offersaudit;

create table offersaudit
(
  offersauditid bigint generated always as identity,
  operation char(1), --i. inserted, u. updated (new values)
  offersid bigint not null,
  userid bigint,
  currencycode char(3),
  campaignid bigint,
  offeredamount numeric,
  acceptedamount numeric,
  status smallint,
  isagreetoterms boolean not null default false,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamp with time zone,
  updatedby bigint,
  updatedat timestamp with time zone
)
  with (
    oids = false
  )
  tablespace pg_default;

