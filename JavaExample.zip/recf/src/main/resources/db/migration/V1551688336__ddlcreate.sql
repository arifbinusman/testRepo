

drop table if exists userroles;
drop table if exists users;
drop table if exists userdetail;
drop table if exists roles;

create table users
(
  id bigserial primary key,
  usertype smallint,
  username varchar(30),
  useremail varchar(30),
  password varchar(100),
  fullname varchar(100),
  isagreetoterms    boolean,
  isemailverified   boolean,
  istwofaregistered smallint,
  isaccountlocked boolean,
  failedloginattempts smallint,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);
create table userdetail
(
  id                bigserial primary key,
  userid            bigint,
  occupation        varchar(100),
  idcardnumber      varchar(200),
  dateofbirth       date,
  accountsource     smallint,
  kycstatus         smallint,
  userstatus        smallint,
  amlfinalstatus    smallint,
  isdeleted boolean not null default false,
  citizenship       smallint,
  createdby         bigint,
  createdat         timestamptz,
  updatedby         bigint,
  updatedat         timestamptz
);
create table roles
(
  id                bigserial primary key,
  name              varchar(255),
  description       varchar(255),
  isdeleted boolean not null default false,
  createdby         bigint,
  createdat         timestamptz,
  updatedby         bigint,
  updatedat         timestamptz

);
create table userroles
(
  userid bigint not null,
  roleid bigint not null,
  primary key (userid, roleid)
);

alter table userroles add constraint FKh8ciramu9cc9q3qcqiv4ue8a6 foreign key (roleid) references roles (id);
alter table userroles add constraint FKhfh9dx7w3ubf1co1vdev94g3f foreign key (userid) references users (id);

INSERT INTO roles(description,name) values ('Admin', 'ADMIN');
INSERT INTO roles(description,name) values ('Investor', 'INVESTOR');