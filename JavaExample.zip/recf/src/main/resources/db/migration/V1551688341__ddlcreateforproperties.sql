drop table if exists properties;

create table properties (
      id                         bigserial primary key,
      propertytype               smallint,
      address                    varchar(1000),
      city                       varchar(100),
      state                      varchar(100),
      zipcode                    varchar(10),
      country                    varchar(50),
      investmentperiod           smallint,
      initialgrosspropertyyieldpa numeric,
      annualisedcashyield         numeric,
      annualisedreturn            numeric,
      thumbnailfileids            bigint[],
      assetprice                  numeric,
      currency                    varchar(3),
      isdeleted                  boolean not null default false,
      createdby                  bigint,
      createdat                  timestamptz,
      updatedby                  bigint,
      updatedat                  timestamptz
);
drop table if exists propertydetails;
create table propertydetails(
      id                          bigserial primary key,
      propertyid                  bigint,
      categoryname                varchar(100),
      categorylabel               varchar(100),
      categorydetails             json,
      fileids                     bigint[],
      parentid                    bigint null ,
      createdby                   bigint,
      createdat                   timestamptz,
      updatedby                   bigint,
      updatedat                   timestamptz
);
