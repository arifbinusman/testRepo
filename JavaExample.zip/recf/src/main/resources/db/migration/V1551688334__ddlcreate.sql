-- noinspection SqlNoDataSourceInspectionForFile

create table offers (
  id bigserial primary key,
  campaignid bigint,
  userid bigint,
  offeredamount decimal,
  acceptedamount decimal,
  status smallint,
  isagreetoterms boolean,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);
