-- Function =: fundTransferInRequest
-- Description =: When user request for fund Transfer in.
-- Steps =: 1. Update or insert data in wallet and wallet audit table. 2. Insert request in FundTransferRequest table 3. Insert record in Transaction table.
-- result =: select fundTransferInRequest(3, 1000.00, 'USD', 'Test', 1);
-- Pending Test =: Return result and concurrency.

CREATE OR REPLACE FUNCTION public.fundTransferOutRequestApprove (request_id bigint, admin_user_id bigint)
RETURNS int AS $BODY$
DECLARE
  result int;
  tranType bigint;
  prevBalance numeric;
  newRequestId bigint;
  req_amount numeric;
  req_cc char(3);
  user_id bigint;
BEGIN
result := 0;
  BEGIN
    -- 1. Get amount from fund transfer request table.
    select amount, userid, currencycode into req_amount, user_id, req_cc from fundtransferrequest where id = request_id;

    -- 1. Update wallet actual balance upon approval.
    with walletUpd as (
      UPDATE wallet SET actualBalance = wallet.actualBalance - req_amount, updatedby = admin_user_id, updatedat = now()
        where userid = user_id and currencycode = req_cc
      returning *)
      insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                              ledgerbalance, createdby, createdat, updatedby, updatedat)
      select 'U', walletUpd.id, walletUpd.userid, walletUpd.currencycode, walletUpd.actualbalance,
             walletUpd.ledgerbalance, walletUpd.createdby, walletUpd.createdat, walletUpd.updatedby, walletUpd.updatedat
      from walletUpd;

    -- 2. Insert record in Fund Transfer Request when received.
    with request as (
      update fundTransferRequest
        set status = 2, -- Approve
        updatedby = admin_user_id,
        updatedat = now()
        where id = request_id
      returning *)
      insert into fundtransferrequestaudit (operation, requestid, userid, amount, currencycode, comment, status,
                                   direction, fileids, createdby, createdat, updatedby, updatedat)
      Select 'U', request.id, request.userid, request.amount, request.currencycode, request.comment, request.status,
             request.direction, request.fileids, request.createdby, request.createdat, request.updatedby, request.updatedat
      from request;
 -- COMMIT;
  --ROLLBACK;
  end;
RETURN result;
END;
$BODY$ LANGUAGE plpgsql;


/*
  INSERT into fundTransferRequest(userId, amount, currencyCode, comment, status, direction, fileIds, createdBy, createdDate)
    values (1, 100.00, 'USD', 'test', 1, 1, ARRAY[1], 1, now())
    returning requestid;
*/

/*
Select * from fundtransferrequest
Select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */