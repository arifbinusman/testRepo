-- Function =: fundTransferInRequest
-- Description =: When user request for fund Transfer in.
-- Steps =: 1. Update or insert data in wallet and wallet audit table. 2. Insert request in FundTransferRequest table 3. Insert record in Transaction table.
-- result =: select fundTransferInRequest(6, 1000.00, 'USD', 'Test', array[1]::int[], 1);
-- Pending Test =: Return result and concurrency.

CREATE OR REPLACE FUNCTION public.fundTransferInRequest (user_id bigint, amount numeric, currency_code char(3), comment varchar(2000), file_ids int[], created_by bigint)
RETURNS int AS $BODY$
DECLARE
  result int;
  tranType bigint;
  prevBalance numeric;
  newRequestId bigint;
BEGIN
result := 0;
  BEGIN
    select transactionTypeId into tranType from transactionType
      where value = 'FundTransferIn';

    -- 1. Insert/Update wallet ledger balance for given user. Updating wallet table first will help to lock that users table.
    with walletUpd as (
    Insert into wallet(userid, currencycode, actualbalance, ledgerbalance, createdby, createdat)
    values (user_id, currency_code, 0, amount, created_by, now())
    ON CONFLICT(userid, currencycode) DO
      UPDATE SET ledgerbalance = wallet.ledgerbalance + amount, updatedby = created_by, updatedat = now()
      returning *, case when updatedby is null then 'I' else 'U' end as upsertStatus)
      insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                              ledgerbalance, createdby, createdat, updatedby, updatedat)
      select walletUpd.upsertStatus, walletUpd.id, walletUpd.userid, walletUpd.currencycode, walletUpd.actualbalance,
             walletUpd.ledgerbalance, walletUpd.createdby, walletUpd.createdat, walletUpd.updatedby, walletUpd.updatedat
      from walletUpd;

    -- 2. Insert record in Fund Transfer Request when received.
    with request as (
      INSERT into fundTransferRequest(userId, amount, currencyCode, comment, status, direction, fileIds, createdBy, createdAt)
      values (user_id, amount, currency_code, comment, 1, 1, file_ids, created_by, now())
      returning *)
      insert into fundtransferrequestaudit (operation, requestid, userid, amount, currencycode, comment, status,
                                   direction, fileids, createdby, createdat, updatedby, updatedat)
      Select 'I', request.id, request.userid, request.amount, request.currencycode, request.comment, request.status,
             request.direction, request.fileids, request.createdby, request.createdAt, request.updatedby, request.updatedat
      from request
      returning requestid into newRequestId;

    --Get the last previous balance.
    select t.newbalance into prevBalance from transactions as t where t.userId = user_id and t.currencyCode = currency_code
      order by t.id desc
      limit 1;

    if prevBalance isnull then
      prevBalance := 0;
    end if;

    -- 2. Insert a record in Transaction Table.
    INSERT into transactions(userId, currencyCode, creditAmount, debitAmount, previousBalance, newBalance, transactionType, transactionsourceid, createdby, createdat)
    values (user_id, currency_code, amount, 0.00, prevBalance, prevBalance + amount, tranType, newRequestId, created_by, now());

 -- COMMIT;
  --ROLLBACK;
  end;
RETURN result;
END;
$BODY$ LANGUAGE plpgsql;


/*
  INSERT into fundTransferRequest(userId, amount, currencyCode, comment, status, direction, fileIds, createdBy, createdDate)
    values (1, 100.00, 'USD', 'test', 1, 1, ARRAY[1], 1, now())
    returning requestid;
*/

/*
Select * from fundtransferrequest
Select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */