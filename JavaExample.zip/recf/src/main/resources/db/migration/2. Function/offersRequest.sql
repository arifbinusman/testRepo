-- Function =: fundTransferInRequest
-- Description =: When user request for fund Transfer in.
-- Steps =: 1. Update or insert data in wallet and wallet audit table. 2. Insert request in FundTransferRequest table 3. Insert record in Transaction table.
-- result =: select public.offerRequest(1, 1, 'USD', 1000.00, true);
-- Pending Test =: Return result and concurrency.

CREATE OR REPLACE FUNCTION public.offerRequest (user_id bigint, campaign_id bigint, currency_code char(3), offered_amount numeric, isAgreeToTerms boolean)
RETURNS int AS $BODY$
DECLARE
  result int;
  tranType bigint;
  prevBalance numeric;
  newRequestId bigint;
  offerId bigint;
BEGIN
result := 0;
  BEGIN
    select transactionTypeId into tranType from transactionType
      where value = 'Offers';

    -- 1. Update wallet actual balance for given user and currency.
    with walletUpd as (
      UPDATE wallet
        SET actualbalance = wallet.actualbalance - offered_amount,
          updatedby = user_id,
          updatedat = now()
        where userid = user_id
        and currencycode = currency_code
      returning *)
      insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                              ledgerbalance, createdby, createdat, updatedby, updatedat)
      select 'U', walletUpd.id, walletUpd.userid, walletUpd.currencycode, walletUpd.actualbalance,
             walletUpd.ledgerbalance, walletUpd.createdby, walletUpd.createdat, walletUpd.updatedby, walletUpd.updatedat
      from walletUpd;

    -- 2. Insert record in Fund Transfer Request when received.
     INSERT into offers(userid, currencycode, campaignid, offeredamount, acceptedamount, status, createdby, createdat)
     values (user_id, currency_code, campaign_id, offered_amount, 0.00, 1, user_id, now())
     returning id into offerId;

    --Get the last previous balance.
    select t.newbalance into prevBalance from transactions as t where t.userId = user_id and t.currencyCode = currency_code
      order by t.id desc
      limit 1;

    if prevBalance isnull then
      prevBalance := 0;
    end if;

    -- 3. Insert a record in Transaction Table.
    INSERT into transactions(userId, currencyCode, creditAmount, debitAmount, previousBalance, newBalance, transactionType, transactionsourceid, createdby, createdat)
    values (user_id, currency_code, 0.00, offered_amount, prevBalance, prevBalance - offered_amount, tranType, offerId, user_id, now());

 -- COMMIT;
  --ROLLBACK;
  end;
RETURN result;
END;
$BODY$ LANGUAGE plpgsql;


/*
  INSERT into fundTransferRequest(userId, amount, currencyCode, comment, status, direction, fileIds, createdBy, createdDate)
    values (1, 100.00, 'USD', 'test', 1, 1, ARRAY[1], 1, now())
    returning requestid;
*/

/*
Select * from fundtransferrequest
Select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */