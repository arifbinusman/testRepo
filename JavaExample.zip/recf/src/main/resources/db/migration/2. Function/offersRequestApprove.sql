-- Function =: fundTransferInRequest
-- Description =: When user request for fund Transfer in.
-- Steps =: 1. Update or insert data in wallet and wallet audit table. 2. Insert request in FundTransferRequest table 3. Insert record in Transaction table.
-- result =: select fundTransferInRequest(3, 1000.00, 'USD', 'Test', 1);
-- Pending Test =: Return result and concurrency.

CREATE OR REPLACE FUNCTION public.offersRequestApprove (offer_id bigint, approved_amount numeric, admin_user_id bigint)
RETURNS int AS $BODY$
DECLARE
  result int;
  tranType bigint;
  prevBalance numeric;
  newRequestId bigint;
  offered_amount numeric;
  req_cc char(3);
  user_id bigint;
BEGIN
result := 0;
  BEGIN
    -- 1. Get amount from fund transfer request table.
    select offeredamount, userid, currencycode into offered_amount, user_id, req_cc from offers where id = offer_id;

    -- 1. Update wallet actual balance upon approval.
    with walletUpd as (
      UPDATE wallet
        SET ledgerbalance = wallet.ledgerbalance - offered_amount,
            updatedby = admin_user_id,
            updatedat = now()
        where userid = user_id and currencycode = req_cc
      returning *)
      insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                              ledgerbalance, createdby, createdat, updatedby, updatedat)
      select 'U', walletUpd.id, walletUpd.userid, walletUpd.currencycode, walletUpd.actualbalance,
             walletUpd.ledgerbalance, walletUpd.createdby, walletUpd.createdat, walletUpd.updatedby, walletUpd.updatedat
      from walletUpd;

    -- 2. Update offered when approved.
    with offer as (
      update offers
        set status = 2, -- Approve
        updatedby = admin_user_id,
        updatedat = now()
        where id = offer_id
      returning *)
      insert into offersaudit (operation, offersid, userid, currencycode, campaignid, offeredamount,
                               acceptedamount, status, createdby, createdat, updatedby, updatedat)
      Select 'U', offer.id, offer.userid, offer.currencycode, offer.campaignid, offer.offeredamount,
             offer.acceptedamount, offer.status, offer.createdby, offer.createdat, offer.updatedby, offer.updatedat
      from offer;
 -- COMMIT;
  --ROLLBACK;
  end;
RETURN result;
END;
$BODY$ LANGUAGE plpgsql;


/*
  INSERT into fundTransferRequest(userId, amount, currencyCode, comment, status, direction, fileIds, createdBy, createdDate)
    values (1, 100.00, 'USD', 'test', 1, 1, ARRAY[1], 1, now())
    returning requestid;
*/

/*
Select * from fundtransferrequest
Select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */