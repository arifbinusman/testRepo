-- Function =: fundTransferInRequest
-- Description =: When user request for fund Transfer in.
-- Steps =: 1. Update or insert data in wallet and wallet audit table. 2. Insert request in FundTransferRequest table 3. Insert record in Transaction table.
-- result =: select public.testFT (4);
-- Pending Test =: Return result and concurrency.

CREATE OR REPLACE FUNCTION public.testFT (user_id bigint)
RETURNS int AS $BODY$
DECLARE
  result int;
  tranType bigint;
  prevBalance numeric;
  newRequestId bigint;
  fundTransReqId bigint;
BEGIN
result := 0;
  BEGIN
    select fundTransferInRequest(user_id, 2000.00, 'USD', 'Test', array[1]::int[], 1) into result;

    select max(id) from fundtransferrequest into fundTransReqId;

    select fundTransferInRequestApprove(fundTransReqId, 999) into result;

    select fundTransferInRequest(user_id, 1000.00, 'USD', 'Test', array[1]::int[], 1) into result;

    select max(id) from fundtransferrequest into fundTransReqId;

    select fundtransferinrequestreject(fundTransReqId, 9999) into result;

    select fundTransferOutRequest(user_id, 500.00, 'USD', 'Test', array[1]::int[], 1) into result;

    select max(id) from fundtransferrequest into fundTransReqId;

    select fundTransferOutRequestApprove(fundTransReqId, 999) into result;

    select fundTransferOutRequest(user_id, 500.00, 'USD', 'Test', array[1]::int[], 1) into result;

    select max(id) from fundtransferrequest into fundTransReqId;

    select fundTransferOutRequestReject(fundTransReqId, 999) into result;

    select offerrequest(user_id, 1, 'USD', 500.00, true) into result;

    select max(id) from offers into fundTransReqId;

    select offersrequestapprove(fundTransReqId, 500.00, 9999) into result;

    select offerrequest(user_id, 1, 'USD', 500.00, true) into result;

    select max(id) from offers into fundTransReqId;

    select offersrequestreject(fundTransReqId, 9999) into result;
 -- COMMIT;
  --ROLLBACK;
  end;
RETURN result;
END;
$BODY$ LANGUAGE plpgsql;


/*
  INSERT into fundTransferRequest(userId, amount, currencyCode, comment, status, direction, fileIds, createdBy, createdDate)
    values (1, 100.00, 'USD', 'test', 1, 1, ARRAY[1], 1, now())
    returning requestid;
*/

/*
Select * from fundtransferrequest
Select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */