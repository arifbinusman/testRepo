-- Function =: fundTransferInRequest
-- Description =: When user request for fund Transfer in.
-- Steps =: 1. Update or insert data in wallet and wallet audit table. 2. Insert request in FundTransferRequest table 3. Insert record in Transaction table.
-- result =: select fundTransferInRequestReject(6, 5);
-- Pending Test =: Return result and concurrency.

CREATE OR REPLACE FUNCTION public.fundTransferInRequestReject (request_id bigint, admin_user_id bigint)
RETURNS int AS $BODY$
DECLARE
  result int;
  tranType bigint;
  req_amount numeric;
  newRequestId bigint;
  prevBalance numeric;
  req_cc char(3);
  user_id bigint;
BEGIN
result := 0;
  BEGIN
    -- 1. Get amount from fund transfer request table.
    select amount, userid, currencycode into req_amount, user_id, req_cc
      from fundtransferrequest
      where id = request_id;

    select transactionTypeId into tranType from transactionType
      where value = 'FundTransferIn';

    -- 1. Update wallet ledger balance for given user upon rejection.
    with walletUpd as (
      UPDATE wallet SET ledgerbalance = wallet.ledgerbalance - req_amount, updatedby = admin_user_id, updatedat = now()
        where userid = user_id and currencycode = req_cc
      returning *)
      insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                              ledgerbalance, createdby, createdat, updatedby, updatedat)
      select 'U', walletUpd.id, walletUpd.userid, walletUpd.currencycode, walletUpd.actualbalance,
             walletUpd.ledgerbalance, walletUpd.createdby, walletUpd.createdat, walletUpd.updatedby, walletUpd.updatedat
      from walletUpd;

    -- 2. Update record in Fund Transfer Request upon rejection.
    with request as (
      UPDATE fundTransferRequest
        set status = 3,
          updatedby = admin_user_id,
          updatedat = now()
        where id = request_id
      returning *)
      insert into fundtransferrequestaudit (operation, requestid, userid, amount, currencycode, comment, status,
                                   direction, fileids, createdby, createdat, updatedby, updatedat)
      Select 'U', request.id, request.userid, request.amount, request.currencycode, request.comment, request.status,
             request.direction, request.fileids, request.createdby, request.createdat, request.updatedby, request.updatedat
      from request
      returning requestid into newRequestId;

        --Get the last previous balance.
    select t.newbalance into prevBalance from transactions as t where t.userId = user_id and t.currencyCode = req_cc
      order by t.id desc
      limit 1;

    if prevBalance isnull then
      prevBalance := 0;
    end if;

    -- 2. Insert a record in Transaction Table.
    INSERT into transactions(userId, currencyCode, creditAmount, debitAmount, previousBalance,
                             newBalance, transactionType, transactionsourceid, createdby, createdat)
    values (user_id, req_cc, 0.00, req_amount, prevBalance,
           prevBalance - req_amount, tranType, newRequestId, admin_user_id, now());

 -- COMMIT;
  --ROLLBACK;
  end;
RETURN result;
END;
$BODY$ LANGUAGE plpgsql;


/*
  INSERT into fundTransferRequest(userId, amount, currencyCode, comment, status, direction, fileIds, createdBy, createdDate)
    values (1, 100.00, 'USD', 'test', 1, 1, ARRAY[1], 1, now())
    returning requestid;
*/

/*
Select * from fundtransferrequest
Select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */