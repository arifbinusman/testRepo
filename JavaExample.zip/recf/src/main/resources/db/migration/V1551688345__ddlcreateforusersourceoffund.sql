ALTER TABLE userdetail
  ADD COLUMN IF NOT EXISTS sourceofwealth varchar(200);