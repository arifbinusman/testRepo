drop table if exists campaign;
create table campaign (
                            id                       bigserial primary key,
                            propertyid               bigint,
                            title                    varchar(200),
                            detaileddescription      varchar(1000),
                            launchdate               date,
                            launchtime               time,
                            expectedamount           numeric,
                            mininvestmentamount      numeric,
                            investmentmultiple       numeric,
                            finalamount              numeric,
                            validityindays           smallint,
                            status                   smallint,
                            isdeleted                boolean not null default false,
                            createdby                bigint,
                            createdat                timestamptz,
                            updatedby                bigint,
                            updatedat                timestamptz
);