create table users (
  id bigserial primary key,
  usertype smallint,
  username varchar(30),
  useremail varchar(30),
  password varchar(100),
  fullname varchar(100),
  occupation varchar(100),
  idcardnumber varchar(200),
  dateofbirth date,
  isagreetoterms boolean,
  isemailverified boolean,
  accountsource smallint,
  istwofaregistered smallint,
  kycstatus smallint,
  userstatus smallint,
  amlfinalstatus smallint,
  isaccountlocked boolean,
  failedloginattempts smallint,
  citizenship smallint,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);

create table originatorcompanyinfo (
  id bigserial primary key,
  userid bigint,
  companyname varchar(100),
  companyregnnumber varchar(50),
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);

create table amldetails (
  id bigserial primary key,
  parentid bigint,
  parenttype smallint,
  amlsearchtype varchar(200),
  amlsearchresult varchar(1000),
  amlsearchcomments varchar(200),
  amlstatus smallint,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);

create table campaigns (
  id bigserial primary key,
  propertyid bigint,
  title varchar(200),
  detaileddescription varchar(1000),
  launchtime timestamptz,
  additionalinfo jsonb,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);

create table useridentities (
  id bigserial primary key,
  parentid bigint,
  parenttype smallint,
  iddocumenttype smallint,
  idnumber varchar(50),
  verificationstatus smallint,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);

create table properties (
  id bigserial primary key,
  companyid bigint,
  propertytype smallint,
  propertysummary varchar(500),
  propertydescription varchar(1000),
  propertyadditionalinfo jsonb,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);

create table originatorcompanyofficers (
  id bigserial primary key,
  companyid bigint,
  offname varchar(200),
  offtype varchar(20),
  offadditionalinfo varchar(200),
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);

create table addresses (
  id bigserial primary key,
  parentid bigint,
  parenttype smallint,
  addresstype smallint,
  address1 varchar(200),
  address2 varchar(200),
  zipcode varchar(20),
  city varchar(50),
  state varchar(50),
  country varchar(50),
  fileid bigint,
  isactive boolean,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);

create table contacts (
  id bigserial primary key,
  parentid bigint,
  parenttype smallint,
  contactdetailtype varchar(20),
  contactdetail varchar(200),
  ispreferredmethod smallint,
  isdeleted boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);
create table files
(
  id bigserial primary key,
  filename 	varchar(200),
  fileextension   varchar(50),
  filedoctype	varchar(50),
  filefullpath	varchar(500),
  actualfilename	varchar(200),
  filesize		bigint,
  filechecksum		varchar(100),
  isdeleted 	boolean not null default false,
  createdby bigint,
  createdat timestamptz,
  updatedby bigint,
  updatedat timestamptz
);
