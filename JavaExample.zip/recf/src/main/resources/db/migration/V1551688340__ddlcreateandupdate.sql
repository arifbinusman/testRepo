drop table if exists userdetail;
create table userdetail
(
  id                bigserial primary key,
  userid            bigint,
  occupation        varchar(100),
  idcardnumber      varchar(200),
  dateofbirth       date,
  accountsource     smallint,
  kycstatus         smallint,
  userstatus        smallint,
  amlfinalstatus    smallint,
  isdeleted boolean not null default false,
  citizenship       varchar(10),
  countryofresident varchar(10),
  createdby         bigint,
  createdat         timestamptz,
  updatedby         bigint,
  updatedat         timestamptz
);