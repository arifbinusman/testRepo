-- Table: public.transactionTypeStatic

-- DELETE from public.transactionType;

INSERT into public.transactionType(value)
  values ('FundTransferIn');

INSERT into public.transactionType(value)
  values ('FundTransferOut');

INSERT into public.transactionType(value)
  values ('Offers');

INSERT into public.transactionType(value)
  values ('Distribution');