
drop table if exists fundtransferrequest;

create table fundtransferrequest
(
  id bigserial primary key,
  userid                  bigint,
  amount                  numeric,
  transactioncomments     varchar(200),
  status                  smallint,
  direction               smallint,
  fileids                 bigint[],
  isdeleted               boolean not null default false,
  createdby               bigint,
  createdat               timestamptz,
  updatedby               bigint,
  updatedat               timestamptz
);