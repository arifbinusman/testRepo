
---------------------------------
-- function =: fundtransferinrequest
-- description =: when user request for fund transfer in.
-- steps =: 1. update or insert data in wallet and wallet audit table. 2. insert request in fundtransferrequest table 3. insert record in transaction table.
-- result =: select public.offerrequest(1, 1, 'usd', 1000.00, true);
-- pending test =: return result and concurrency.

create or replace function offerrequest (user_id bigint, campaign_id bigint, currency_code varchar(3), offered_amount numeric, isagreetoterms boolean)
  returns int as $body$
declare
  result int;
  trantype bigint;
  prevbalance numeric;
  newrequestid bigint;
  offerid bigint;
begin
  result := 0;
  begin
    select transactiontypeid into trantype from transactiontype
    where value = 'offers';

    -- 1. update wallet actual balance for given user and currency.
    with walletupd as (
      update wallet
        set actualbalance = wallet.actualbalance - offered_amount,
          updatedby = user_id,
          updatedat = now()
        where userid = user_id
          and currencycode = currency_code
        returning *)
    insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                            ledgerbalance, createdby, createdat, updatedby, updatedat)
    select 'u', walletupd.id, walletupd.userid, walletupd.currencycode, walletupd.actualbalance,
           walletupd.ledgerbalance, walletupd.createdby, walletupd.createdat, walletupd.updatedby, walletupd.updatedat
    from walletupd;

    -- 2. insert record in fund transfer request when received.
    insert into offers(userid, currencycode, campaignid, offeredamount, acceptedamount, status, createdby, createdat)
    values (user_id, currency_code, campaign_id, offered_amount, 0.00, 1, user_id, now())
           returning id into offerid;

    --get the last previous balance.
    select t.newbalance into prevbalance from transactions as t where t.userid = user_id and t.currencycode = currency_code
    order by t.id desc
    limit 1;

    if prevbalance isnull then
      prevbalance := 0;
    end if;

    -- 3. insert a record in transaction table.
    insert into transactions(userid, currencycode, creditamount, debitamount, previousbalance, newbalance, transactiontype, transactionsourceid, createdby, createdat)
    values (user_id, currency_code, 0.00, offered_amount, prevbalance, prevbalance - offered_amount, trantype, offerid, user_id, now());

    -- commit;
    --rollback;
  end;
  return result;
end;
$body$ language plpgsql;


/*
  insert into fundtransferrequest(userid, amount, currencycode, comment, status, direction, fileids, createdby, createddate)
    values (1, 100.00, 'usd', 'test', 1, 1, array[1], 1, now())
    returning requestid;
*/

/*
select * from fundtransferrequest
select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */
------------------------------------------------------


-- function =: fundtransferinrequest
-- description =: when user request for fund transfer in.
-- steps =: 1. update or insert data in wallet and wallet audit table. 2. insert request in fundtransferrequest table 3. insert record in transaction table.
-- result =: select fundtransferinrequest(3, 1000.00, 'usd', 'test', 1);
-- pending test =: return result and concurrency.

create or replace function offerrrequestapprove (offer_id bigint, approved_amount numeric, admin_user_id bigint)
  returns int as $body$
declare
  result int;
  trantype bigint;
  prevbalance numeric;
  newrequestid bigint;
  offered_amount numeric;
  req_cc char(3);
  user_id bigint;
begin
  result := 0;
  begin
    -- 1. get amount from fund transfer request table.
    select offeredamount, userid, currencycode into offered_amount, user_id, req_cc from offers where id = offer_id;


    -- 2. update accepted amount when approved.
    with offer as (
      update offers
        set status = 2, -- approve
          updatedby = admin_user_id,
          updatedat = now(),
          acceptedamount=offeredamount
        where id = offer_id
        returning *)
    insert into offersaudit (operation, offersid, userid, currencycode, campaignid, offeredamount,
                             acceptedamount, status, createdby, createdat, updatedby, updatedat)
    select 'u', offer.id, offer.userid, offer.currencycode, offer.campaignid, offer.offeredamount,
           offer.acceptedamount, offer.status, offer.createdby, offer.createdat, offer.updatedby, offer.updatedat
    from offer;
    -- commit;
    --rollback;
  end;
  return result;
end;
$body$ language plpgsql;


/*
  insert into fundtransferrequest(userid, amount, currencycode, comment, status, direction, fileids, createdby, createddate)
    values (1, 100.00, 'usd', 'test', 1, 1, array[1], 1, now())
    returning requestid;
*/

/*
select * from fundtransferrequest
select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */
------------------------------------------------------
-- function =: fundtransferinrequest
-- description =: when user request for fund transfer in.
-- steps =: 1. update or insert data in wallet and wallet audit table. 2. insert request in fundtransferrequest table 3. insert record in transaction table.
-- result =: select fundtransferinrequest(3, 1000.00, 'usd', 'test', 1);
-- pending test =: return result and concurrency.

create or replace function offersrequestreject (offer_id bigint, admin_user_id bigint)
  returns int as $body$
declare
  result int;
  trantype bigint;
  prevbalance numeric;
  newrequestid bigint;
  offered_amount numeric;
  req_cc char(3);
  user_id bigint;
begin
  result := 0;
  begin
    -- 1. get amount from fund transfer request table.
    select offeredamount, userid, currencycode into offered_amount, user_id, req_cc
    from offers
    where id = offer_id and status=1;

    select transactiontypeid into trantype from transactiontype
    where value = 'offers';

    -- 1. update wallet ledger balance for given user upon rejection.
    with walletupd as (
      update wallet
        set actualbalance = wallet.actualbalance + offered_amount,
          updatedby = admin_user_id,
          updatedat = now()
        where userid = user_id and currencycode = req_cc
        returning *)
    insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                            ledgerbalance, createdby, createdat, updatedby, updatedat)
    select 'u', walletupd.id, walletupd.userid, walletupd.currencycode, walletupd.actualbalance,
           walletupd.ledgerbalance, walletupd.createdby, walletupd.createdat, walletupd.updatedby, walletupd.updatedat
    from walletupd;

    -- 2. update record in fund transfer request upon rejection.
    with offer as (
      update offers
        set status = 3, -- reject
          updatedby = admin_user_id,
          updatedat = now()
        where id = offer_id
        returning *)
    insert into offersaudit (operation, offersid, userid, currencycode, campaignid, offeredamount,
                             acceptedamount, status, createdby, createdat, updatedby, updatedat)
    select 'u', offer.id, offer.userid, offer.currencycode, offer.campaignid, offer.offeredamount,
           offer.acceptedamount, offer.status, offer.createdby, offer.createdat, offer.updatedby, offer.updatedat
    from offer;

    --get the last previous balance.
    select t.newbalance into prevbalance from transactions as t where t.userid = user_id and t.currencycode = req_cc
    order by t.id desc
    limit 1;

    if prevbalance isnull then
      prevbalance := 0;
    end if;

    -- 2. insert a record in transaction table.
    insert into transactions(userid, currencycode, creditamount, debitamount, previousbalance,
                             newbalance, transactiontype, transactionsourceid, createdby, createdat)
    values (user_id, req_cc, offered_amount, 0.00, prevbalance,
            prevbalance + offered_amount, trantype, offer_id, user_id, now());

    -- commit;
    --rollback;
  end;
  return result;
end;
$body$ language plpgsql;


/*
  insert into fundtransferrequest(userid, amount, currencycode, comment, status, direction, fileids, createdby, createddate)
    values (1, 100.00, 'usd', 'test', 1, 1, array[1], 1, now())
    returning requestid;
*/

/*
select * from fundtransferrequest
select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */