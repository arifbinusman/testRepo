-- Table: public.offersAudit

-- DROP TABLE public.offersAudit;

CREATE TABLE public.offersAudit
(
    offersAuditId bigint GENERATED ALWAYS AS IDENTITY,
    operation char(1), --I. Inserted, U. Updated (New Values)
    offersId bigint NOT NULL,
    userId bigint,
    currencyCode char(3),
    campaignId BIGINT,
    offeredAmount numeric,
    acceptedAmount numeric,
    status smallint,
    isAgreeToTerms boolean NOT NULL DEFAULT false,
    isDeleted boolean NOT NULL DEFAULT false,
    createdBy bigint,
    createdAt timestamp with time zone,
    updatedBy bigint,
    updatedAt timestamp with time zone,
    CONSTRAINT offersAuditPK PRIMARY KEY (offersAuditId)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.offers
    OWNER to recfdev;