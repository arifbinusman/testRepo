-- Table: public.fundTransferRequestAudit

-- DROP TABLE public.fundTransferRequestAudit;

CREATE TABLE public.fundTransferRequestAudit
(
    requestAuditId bigint GENERATED ALWAYS AS IDENTITY,
    operation char(1), --I. Inserted, U. Updated (New Values)
    requestId bigint,
    userId bigint,
    amount numeric,
    currencyCode char(3),
    comment character varying(2000) COLLATE pg_catalog."default",
    status smallint, --1 - Submitted, 2 Accepted, 3 Rejected, 4 Cancelled, 5 Dispute
    direction smallint, --1 -- In, 2-- Out
    fileIds bigint[], -- List of File Ids.
    isDeleted boolean NOT NULL DEFAULT false,
    createdBy bigint,
    createdAt timestamp with time zone,
    updatedBy bigint,
    updatedAt timestamp with time zone,
    CONSTRAINT fundTransferRequestPrimaryKey PRIMARY KEY (requestAuditId)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

create index idx_requestid
on public.fundTransferRequestAudit(requestId);

ALTER TABLE public.fundTransferRequest
    OWNER to recfdev;