-- Table: public.fundtransferrequest

 -- alter table public.fundTransferRequest drop constraint fundTransferRequestPrimaryKey;
-- DROP TABLE public.fundTransferRequest;


CREATE TABLE public.fundTransferRequest
(
    id bigint GENERATED ALWAYS AS IDENTITY,
    userId bigint,
    amount numeric,
    currencyCode char(3),
    comment character varying(2000) COLLATE pg_catalog."default",
    status smallint, --1 - Submitted, 2 Accepted, 3 Rejected, 4 Cancelled, 5 Dispute
    direction smallint, --1 -- In, 2-- Out
    fileIds bigint[], -- List of File Ids.
    isDeleted boolean NOT NULL DEFAULT false,
    createdBy bigint,
    createdAt timestamp with time zone,
    updatedBy bigint,
    updatedAt timestamp with time zone,
    CONSTRAINT fundTransferRequestPK PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.fundTransferRequest
    OWNER to recfdev;