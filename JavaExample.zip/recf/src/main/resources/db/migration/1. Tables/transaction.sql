-- Table: public.usertransactions

-- DROP TABLE public.transactions;

CREATE TABLE public.transactions
(
    id bigint GENERATED ALWAYS AS IDENTITY,
    userId bigint NOT NULL,
    currencyCode CHAR(3),
    creditAmount numeric NOT NULL,
    debitAmount numeric NOT NULL,
    previousBalance numeric NOT NULL,
    newBalance numeric NOT NULL,
    transactionType smallint NOT NULL,
    transactionSourceId bigint NOT NULL,
    createdBy bigint NOT NULL,
    createdAt timestamp with time zone NOT NULL,
    CONSTRAINT transactionPK PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.transactions
    OWNER to recfdev;

-- Index: usertransactions_userid_currencycode_createdat_idx

-- DROP INDEX public.usertransactions_userid_currencycode_createdat_idx;

CREATE INDEX transactionUIDCCD
    ON public.transactions USING btree
    (userId, currencyCode COLLATE pg_catalog."default", createdDate)
    TABLESPACE pg_default;