-- Table: public.wallet

-- DROP TABLE public.wallet;

CREATE TABLE public.wallet
(
    id bigint GENERATED ALWAYS AS IDENTITY,
    userId bigint,
    currencyCode char(3),
    actualBalance numeric,
    ledgerBalance numeric,
    createdBy bigint,
    createdAt timestamp with time zone,
    updatedBy bigint,
    updatedAt timestamp with time zone,
    CONSTRAINT walletPK PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.wallet
    OWNER to recfdev;

CREATE UNIQUE INDEX walletUniqueUIDCC ON wallet (userId, currencyCode);