-- Table: public.transactionType

-- DROP TABLE public.transactionType;

CREATE TABLE public.transactionType
(
    transactionTypeId smallint GENERATED ALWAYS AS IDENTITY,
    value char(20),
    CONSTRAINT transactionTypePrimaryKey PRIMARY KEY (transactionTypeId)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.transactionType
    OWNER to recfdev;
