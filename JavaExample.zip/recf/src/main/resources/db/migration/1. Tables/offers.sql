-- Table: public.offers

-- DROP TABLE public.offers;

CREATE TABLE public.offers
(
    id bigint GENERATED ALWAYS AS IDENTITY,
    userId bigint,
    currencyCode char(3),
    campaignId BIGINT,
    offeredAmount numeric,
    acceptedAmount numeric,
    status smallint, --1. Submitted, 2. Approve, 3. Rejected.
    isAgreeToTerms boolean NOT NULL DEFAULT false,
    isDeleted boolean NOT NULL DEFAULT false,
    createdBy bigint,
    createdAt timestamp with time zone,
    updatedBy bigint,
    updatedAt timestamp with time zone,
    CONSTRAINT offersPK PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.offers
    OWNER to recfdev;