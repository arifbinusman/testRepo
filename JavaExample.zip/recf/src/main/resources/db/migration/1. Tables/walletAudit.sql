-- Table: public.walletAudit

-- DROP TABLE public.walletAudit;

CREATE TABLE public.walletAudit
(
    walletAuditId bigint GENERATED ALWAYS AS IDENTITY,
    operation char(1), -- 'I' Insert, 'U' Update.
    walletId bigint not null,
    userId bigint not null,
    currencyCode char(3),
    actualBalance numeric,
    ledgerBalance numeric,
    createdBy bigint,
    createdAt timestamp with time zone,
    updatedBy bigint,
    updatedAt timestamp with time zone,
    CONSTRAINT walletAuditPrimaryKey PRIMARY KEY (walletAuditId)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.walletAudit
    OWNER to recfdev;

CREATE INDEX idx_walletaudit ON walletAudit (walletId);