-------------------------------------------
-- function =: fundtransferoutrequest
-- description =: when user request for fund transfer in.
-- steps =: 1. update or insert data in wallet and wallet audit table. 2. insert request in fundtransferrequest table 3. insert record in transaction table.
-- result =: select fundtransferoutrequest(6, 500.00, 'usd', 'test', array[1]::int[], 1);
-- pending test =: return result and concurrency, file ids need to update.

create or replace function fundtransferoutrequest (user_id bigint, amount numeric, currency_code varchar(3), comment varchar(2000), created_by bigint)
  returns int as $body$
declare
  result int;
  trantype bigint;
  prevbalance numeric;
  newrequestid bigint;
begin
  result := 0;
  begin
    select transactiontypeid into trantype from transactiontype
    where value = 'fundtransferout';

    -- 1. insert/update wallet ledger balance for given user. updating wallet table first will help to lock that users table.
    with walletupd as (
      insert into wallet(userid, currencycode, actualbalance, ledgerbalance, createdby, createdat)
        values (user_id, currency_code, 0, -amount, created_by, now())
        on conflict(userid, currencycode) do
          update set actualbalance = wallet.actualbalance - amount,ledgerbalance = wallet.ledgerbalance + amount, updatedby = created_by, updatedat = now()
        returning *, case when updatedby is null then 'i' else 'u' end as upsertstatus)
    insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                            ledgerbalance, createdby, createdat, updatedby, updatedat)
    select walletupd.upsertstatus, walletupd.id, walletupd.userid, walletupd.currencycode, walletupd.actualbalance,
           walletupd.ledgerbalance, walletupd.createdby, walletupd.createdat, walletupd.updatedby, walletupd.updatedat
    from walletupd;

    -- 2. insert record in fund transfer request when received.
    with request as (
      insert into fundtransferrequest(userid, amount, currencycode, comment, status, direction, fileids, createdby, createdat)
        values (user_id, amount, currency_code, comment, 1, 2, NULL , created_by, now())
        returning *)
    insert into fundtransferrequestaudit (operation, requestid, userid, amount, currencycode, comment, status,
                                          direction, fileids, createdby, createdat, updatedby, updatedat)
    select 'i', request.id, request.userid, request.amount, request.currencycode, request.comment, request.status,
           request.direction, request.fileids, request.createdby, request.createdat, request.updatedby, request.updatedat
    from request
         returning requestid into newrequestid;

    --get the last previous balance.
    select t.newbalance into prevbalance from transactions as t where t.userid = user_id and t.currencycode = currency_code
    order by t.id desc
    limit 1;

    if prevbalance isnull then
      prevbalance := 0;
    end if;

    -- 3. insert a record in transaction table.
    insert into transactions(userid, currencycode, creditamount, debitamount, previousbalance, newbalance, transactiontype, transactionsourceid, createdby, createdat)
    values (user_id, currency_code, 0.00, amount, prevbalance, prevbalance - amount, trantype, newrequestid, created_by, now());

    -- commit;
    --rollback;
  end;
  return result;
end;
$body$ language plpgsql;


/*
  insert into fundtransferrequest(userid, amount, currencycode, comment, status, direction, fileids, createdby, createddate)
    values (1, 100.00, 'usd', 'test', 1, 1, array[1], 1, now())
    returning requestid;

    select t.newbalance from transactions as t where t.userid = 1 and t.currencycode = 'usd'
      order by t.transactionid desc
      limit 1

*/

/*
select * from fundtransferrequest
select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */
---------------------------------------------------
-- function =: fundtransferinrequest
-- description =: when user request for fund transfer in.
-- steps =: 1. update or insert data in wallet and wallet audit table. 2. insert request in fundtransferrequest table 3. insert record in transaction table.
-- result =: select fundtransferinrequest(3, 1000.00, 'usd', 'test', 1);
-- pending test =: return result and concurrency.

create or replace function fundtransferoutrequestapprove(request_id bigint, admin_user_id bigint)
  returns int as $body$
declare
  result int;
  trantype bigint;
  prevbalance numeric;
  newrequestid bigint;
  req_amount numeric;
  req_cc char(3);
  user_id bigint;
begin
  result := 0;
  begin
    -- 1. get amount from fund transfer request table.
    select amount, userid, currencycode into req_amount, user_id, req_cc from fundtransferrequest where id = request_id and status=1;

    -- 1. update wallet actual balance upon approval.
    with walletupd as (
      update wallet set ledgerbalance = wallet.ledgerbalance - req_amount, updatedby = admin_user_id, updatedat = now()
        where userid = user_id and currencycode = req_cc
        returning *)
    insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                            ledgerbalance, createdby, createdat, updatedby, updatedat)
    select 'u', walletupd.id, walletupd.userid, walletupd.currencycode, walletupd.actualbalance,
           walletupd.ledgerbalance, walletupd.createdby, walletupd.createdat, walletupd.updatedby, walletupd.updatedat
    from walletupd;

    -- 2. insert record in fund transfer request when received.
    with request as (
      update fundtransferrequest
        set status = 2, -- approve
          updatedby = admin_user_id,
          updatedat = now()
        where id = request_id
        returning *)
    insert into fundtransferrequestaudit (operation, requestid, userid, amount, currencycode, comment, status,
                                          direction, fileids, createdby, createdat, updatedby, updatedat)
    select 'u', request.id, request.userid, request.amount, request.currencycode, request.comment, request.status,
           request.direction, request.fileids, request.createdby, request.createdat, request.updatedby, request.updatedat
    from request;
    -- commit;
    --rollback;
  end;
  return result;
end;
$body$ language plpgsql;


/*
  insert into fundtransferrequest(userid, amount, currencycode, comment, status, direction, fileids, createdby, createddate)
    values (1, 100.00, 'usd', 'test', 1, 1, array[1], 1, now())
    returning requestid;
*/

/*
select * from fundtransferrequest
select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */
---------------------------------------------
-- function =: fundtransferinrequest
-- description =: when user request for fund transfer in.
-- steps =: 1. update or insert data in wallet and wallet audit table. 2. insert request in fundtransferrequest table 3. insert record in transaction table.
-- result =: select fundtransferinrequest(3, 1000.00, 'usd', 'test', 1);
-- pending test =: return result and concurrency.

create or replace function fundtransferoutrequestreject (request_id bigint, admin_user_id bigint)
  returns int as $body$
declare
  result int;
  trantype bigint;
  prevbalance numeric;
  newrequestid bigint;
  req_amount numeric;
  req_cc char(3);
  user_id bigint;
begin
  result := 0;
  begin
    -- 1. get amount from fund transfer request table.
    select amount, userid, currencycode into req_amount, user_id, req_cc
    from fundtransferrequest
    where id = request_id and status=1;

    select transactiontypeid into trantype from transactiontype
    where value = 'fundtransferin';

    -- 1. update wallet ledger balance for given user upon rejection.
    with walletupd as (
      update wallet set actualbalance = wallet.actualbalance + req_amount,ledgerbalance = wallet.ledgerbalance - req_amount, updatedby = admin_user_id, updatedat = now()
        where userid = user_id and currencycode = req_cc
        returning *)
    insert into walletaudit(operation, walletid, userid, currencycode, actualbalance,
                            ledgerbalance, createdby, createdat, updatedby, updatedat)
    select 'u', walletupd.id, walletupd.userid, walletupd.currencycode, walletupd.actualbalance,
           walletupd.ledgerbalance, walletupd.createdby, walletupd.createdat, walletupd.updatedby, walletupd.updatedat
    from walletupd;

    -- 2. update record in fund transfer request upon rejection.
    with request as (
      update fundtransferrequest
        set status = 3, -- reject
          updatedby = admin_user_id,
          updatedat = now()
        where id = request_id
        returning *)
    insert into fundtransferrequestaudit (operation, requestid, userid, amount, currencycode, comment, status,
                                          direction, fileids, createdby, createdat, updatedby, updatedat)
    select 'u', request.id, request.userid, request.amount, request.currencycode, request.comment, request.status,
           request.direction, request.fileids, request.createdby, request.createdat, request.updatedby, request.updatedat
    from request
         returning requestid into newrequestid;

    --get the last previous balance.
    select t.newbalance into prevbalance from transactions as t where t.userid = user_id and t.currencycode = req_cc
    order by t.id desc
    limit 1;

    if prevbalance isnull then
      prevbalance := 0;
    end if;

    -- 2. insert a record in transaction table.
    insert into transactions(userid, currencycode, creditamount, debitamount, previousbalance,
                             newbalance, transactiontype, transactionsourceid, createdby, createdat)
    values (user_id, req_cc, req_amount, 0.00, prevbalance,
            prevbalance + req_amount, trantype, newrequestid, admin_user_id, now());

    -- commit;
    --rollback;
  end;
  return result;
end;
$body$ language plpgsql;


/*
  insert into fundtransferrequest(userid, amount, currencycode, comment, status, direction, fileids, createdby, createddate)
    values (1, 100.00, 'usd', 'test', 1, 1, array[1], 1, now())
    returning requestid;
*/

/*
select * from fundtransferrequest
select * from fundtransferrequestaudit
select * from transactions
select * from wallet
select * from walletaudit
 */