
drop table if exists amldetails;
create table amldetails (
    id bigserial primary key,
    userId                bigint,
    amlsearchtype         varchar(500),
    amlsearchresult       varchar(2000),
    amlsearchcomments     varchar(500),
    amlstatus             smallint,
    isdeleted             boolean not null default false,
    createdby             bigint,
    createdat             timestamptz,
    updatedby             bigint,
    updatedat             timestamptz
);

drop table if exists useridentities;
create table useridentities (
    id bigserial primary key,
    userid              bigint,
    iddocumenttype      smallint,
    idnumber            varchar(100),
    verificationstatus  smallint,
    fileids             bigint[],
    isdeleted           boolean not null default false,
    createdby           bigint,
    createdat           timestamptz,
    updatedby           bigint,
    updatedat           timestamptz
);

drop table if exists addresses;
create table addresses (
   id                       bigserial primary key,
   userid                   bigint,
   addresstype              smallint,
   address1                 varchar(200),
   address2                 varchar(200),
   zipcode                  varchar(20),
   city                     varchar(50),
   state                    varchar(50),
   country                  varchar(50),
   fileids                  bigint[],
   isactive                 boolean,
   isdeleted                boolean not null default false,
   createdby                bigint,
   createdat                timestamptz,
   updatedby                bigint,
   updatedat                timestamptz
);
drop table if exists contacts;
create table contacts (
    id                bigserial primary key,
    userid            bigint,
    contactdetailtype varchar(20),
    contactdetail     varchar(200),
    ispreferredmethod smallint,
    isdeleted         boolean not null default false,
    createdby         bigint,
    createdat         timestamptz,
    updatedby         bigint,
    updatedat         timestamptz
);